"""Starimo CLI — serve notebooks or run the spawner daemon standalone."""


import asyncio
import importlib
import logging
import sys
import threading
import time
from pathlib import Path

import click
import httpx
import uvicorn

from starimo.spawner import StarimoSpawner, create_spawner_app

DEFAULT_SPAWNER_PORT = 2718
DEFAULT_THEME = "rationalist_v1"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)


class _ShutdownFilter(logging.Filter):
    """Suppress CancelledError noise from SSE streams on shutdown."""

    def filter(self, record):
        if record.exc_info and record.exc_info[0] is asyncio.CancelledError:
            return False
        msg = record.getMessage()
        if "CancelledError" in msg or "timeout graceful shutdown" in msg:
            return False
        return True


def _run_spawner_in_thread(port: int, host: str = "127.0.0.1") -> None:
    app = create_spawner_app(StarimoSpawner())
    config = uvicorn.Config(app, host=host, port=port, log_level="warning")
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(uvicorn.Server(config).serve())


def _wait_for_spawner(port: int, timeout: float = 5.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if httpx.get(f"http://127.0.0.1:{port}/health", timeout=1.0).status_code == 200:
                logger.info(f"Spawner ready on port {port}")
                return
        except httpx.ConnectError:
            time.sleep(0.2)
    logger.error(f"Spawner failed to start within {timeout}s")
    sys.exit(1)


def _load_theme_app(theme: str, notebook: str):
    try:
        theme_app_module = importlib.import_module(f"starimo.ui.themes.{theme}.app")
    except ModuleNotFoundError:
        raise click.ClickException(f"Theme '{theme}' not found or has no app.py")

    create_app = getattr(theme_app_module, "create_app", None)
    if create_app is None:
        raise click.ClickException(f"Theme '{theme}' app.py has no create_app() factory")

    return create_app(notebook)


def _create_empty_notebook(path: Path) -> None:
    import secrets
    from marimo._ast.cell import CellConfig
    from marimo._ast.codegen import generate_filecontents

    cell_name = f"cell_{secrets.token_hex(4)}"
    content = generate_filecontents(
        codes=[""],
        names=[cell_name],
        cell_configs=[CellConfig()],
    )
    path.write_text(content)


@click.group()
def main() -> None:
    """Starimo — reactive notebooks with Datastar."""


@main.command()
@click.argument("notebook", type=click.Path())
@click.option("--theme", default=DEFAULT_THEME, show_default=True, help="UI theme")
@click.option("--port", type=int, default=8001, show_default=True)
@click.option("--host", default="0.0.0.0", show_default=True)
@click.option("--spawner-port", type=int, default=DEFAULT_SPAWNER_PORT, show_default=True)
def serve(notebook: str, theme: str, port: int, host: str, spawner_port: int) -> None:
    """Serve a notebook with a theme."""
    threading.Thread(target=_run_spawner_in_thread, args=(spawner_port,), daemon=True).start()
    _wait_for_spawner(spawner_port)

    notebook_path = Path(notebook).resolve()

    # Match `marimo edit` behavior: auto-create missing notebooks
    if not notebook_path.exists():
        if not notebook_path.parent.exists():
            raise click.ClickException(f"Parent directory does not exist: {notebook_path.parent}")
        _create_empty_notebook(notebook_path)
        logger.info(f"Created {notebook_path}")

    app = _load_theme_app(theme, str(notebook_path))

    logger.info(f"Starimo — http://{host}:{port}")

    # SSE streams cause noisy CancelledError tracebacks on shutdown
    logging.getLogger("uvicorn.error").addFilter(_ShutdownFilter())

    uvicorn.run(
        app, host=host, port=port,
        log_level="info",
        timeout_graceful_shutdown=0,
    )


@main.command()
@click.option("--host", default="127.0.0.1", show_default=True)
@click.option("--port", type=int, default=DEFAULT_SPAWNER_PORT, show_default=True)
@click.option("--base-notebook-port", type=int, default=2719, show_default=True)
def daemon(host: str, port: int, base_notebook_port: int) -> None:
    """Run spawner daemon only (for multi-notebook setups)."""
    app = create_spawner_app(StarimoSpawner(base_port=base_notebook_port))
    logger.info(f"Starimo Spawner — http://{host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
