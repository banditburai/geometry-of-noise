"""Starimo — reactive notebook UI connecting Datastar frontends to Marimo backends."""

__version__ = "0.1.0"

from starimo.core import ReactiveSignal, get_or_create_signal
from starimo.plugin import StarimoPlugin


def cell(func):
    """AST marker for stardust's build-time cell extraction.

    Functions decorated with ``@cell`` are scanned by ``stardust.analyzer`` and
    converted into marimo cells in the generated notebook (``__marimo__/app.py``).
    At runtime in Pyodide the decorator is an identity pass-through — the real
    reactive behavior comes from the generated marimo notebook, not from calling
    the decorated function directly.
    """
    return func


__all__ = ["StarimoPlugin", "ReactiveSignal", "cell", "get_or_create_signal"]
