import asyncio
import logging
import re
import secrets
from typing import Any

from marimo._ast.parse import fixed_dedent

from starlette.requests import Request
from starlette.responses import JSONResponse, StreamingResponse
from starhtml.server import APIRouter
from starhtml.realtime import (
    format_signal_event, format_element_event, format_event, SSE_HEADERS,
    Relay, SSE_KEEPALIVE_TIMEOUT,
)

from fastcore.xml import to_xml
from starhtml import Span
from starhtml.datastar import Signal, scroll_to

from starimo.core import CELLS_CONTAINER_ID, is_markdown, normalize_cell_name, unwrap_markdown
from starimo.renderer import DefaultRenderer

logger = logging.getLogger(__name__)

_PACKAGE_NAME_RE = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9._-]*(\[[a-zA-Z0-9,_-]+\])?$')


def _get_relay(request: Request) -> Relay:
    return request.app.state.starimo_relay


def _get_bridge(request: Request) -> Any:
    return request.app.state.starimo_bridge


def create_starimo_router(
    initial_values: dict[str, Any] | None = None,
    debounce_map: dict[str, int] | None = None,
    renderer: DefaultRenderer | None = None,
) -> APIRouter:
    initial_values = initial_values or {}
    debounce_map = debounce_map or {}
    renderer = renderer or DefaultRenderer()
    logger.debug(f"create_starimo_router: signals={list(initial_values)}, debounce_map={debounce_map}")
    router = APIRouter(prefix="/starimo")

    def _annex_attribution(source_name: str, cell_num: int | None):
        label = f"\u2190 from {source_name}" + (f" ({cell_num:02d})" if cell_num else "")
        ui_active = Signal("ui_active_cell", "")
        return Span(
            label, cls="output-annex-attribution",
            data_on_click=[scroll_to(f"#cell-{source_name}"), ui_active.set(source_name)],
        )

    @router("/sse", methods=["GET"])
    async def sse_stream(request: Request) -> StreamingResponse:
        bridge = _get_bridge(request)
        relay = _get_relay(request)

        async def event_generator():
            queue = relay.subscribe()

            try:
                if bridge is None:
                    initial = {
                        "starimo_status": "error",
                        "starimo_ready": False,
                        "starimo_error": "Bridge not connected",
                        "starimo_signals": [],
                    }
                else:
                    initial = {
                        **initial_values,
                        **bridge.variables,
                        "starimo_status": "connected" if bridge.connected else "disconnected",
                        "starimo_ready": bridge.ready,
                        "starimo_signals": list(initial_values),
                    }
                    if debounce_map:
                        initial["starimo_signal_debounce"] = debounce_map

                logger.debug(f"SSE initial: starimo_signals={initial.get('starimo_signals')}")
                yield format_signal_event(initial)

                if bridge is not None:
                    renderer.reset_cell_counter()
                    cells = bridge.cells
                    user_cells = [(n, c) for n, c in cells.items() if not n.startswith("_starimo_")]
                    total_cells = len(user_cells)
                    all_cells = [(n, i + 1) for i, (n, _) in enumerate(user_cells)]

                    for name, cell in user_cells:
                        display_code = (unwrap_markdown(cell.code) or cell.code) if cell.is_markdown else cell.code

                        cell_html = renderer.render_editable_cell(
                            name, display_code, cell.hide_code, is_markdown=cell.is_markdown,
                            total_cells=total_cells, all_cells=all_cells,
                            note=cell.note, output_target=cell.output_target,
                        )
                        yield format_element_event(cell_html, f"#{CELLS_CONTAINER_ID}", mode="append", preserve_whitespace=True)

                        if cell.output and isinstance(cell.output, dict):
                            output_content = renderer.render_output_content(
                                cell.output.get("mimetype", "text/plain"),
                                cell.output.get("data", ""),
                                cell.output.get("channel"),
                                cell_id=name,
                            )
                            target = cell.output_target
                            if target:
                                cell_num = dict(all_cells).get(name)
                                yield format_element_event(_annex_attribution(name, cell_num), f"#output-annex-{target}", mode="inner")
                                yield format_element_event(output_content, f"#output-annex-{target}", mode="append")
                                yield format_element_event("", f"#output-content-{name}", mode="inner")
                            else:
                                yield format_element_event(output_content, f"#output-content-{name}", mode="inner")

                    logger.debug(f"SSE: restored {len(cells)} cells")

                while True:
                    try:
                        event = await asyncio.wait_for(queue.get(), timeout=SSE_KEEPALIVE_TIMEOUT)
                        yield format_event(event)
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
                    except asyncio.CancelledError:
                        break
            finally:
                relay.unsubscribe(queue)

        return StreamingResponse(event_generator(), media_type="text/event-stream", headers=SSE_HEADERS)

    @router("/cell", methods=["POST"])
    async def add_cell(request: Request) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        relay = _get_relay(request)

        try:
            data = await request.json()
            after_cell_id = data.get("after_cell_id")
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        cell_id = f"cell_{secrets.token_hex(4)}"
        bridge.insert_cell(cell_id, "", after_cell_id)
        _emit_all_cells(bridge, relay, autofocus_cell=cell_id)

        return JSONResponse({"ok": True, "cell_id": cell_id})

    @router("/install-package/{cell_id}", methods=["POST"])
    async def install_package(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        relay = _get_relay(request)
        try:
            data = await request.json()
            package = data.get("package", "")
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        if not package or not _PACKAGE_NAME_RE.match(package):
            return JSONResponse({"error": "Invalid package name"}, status_code=400)
        try:
            result = await bridge.install_package(package)
            if result.get("success"):
                if bridge.get_cell(cell_id):
                    relay.emit_element(
                        Span("Re-running cell…", cls="output-placeholder"),
                        f"#output-content-{cell_id}",
                        mode="inner",
                    )
                    relay.emit_signals({f"{cell_id}_status": "running"})
                    await bridge.run_cell(cell_id)
                return JSONResponse({"ok": True, "package": package})
            return JSONResponse({"ok": False, "error": result.get("error", "Install failed")})
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/cell/{cell_id}", methods=["DELETE"])
    async def delete_cell(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        relay = _get_relay(request)

        user_cells = [name for name in bridge.cells if not name.startswith("_starimo_")]
        if len(user_cells) <= 1:
            return JSONResponse({"error": "Cannot delete the last cell"}, status_code=400)

        try:
            await bridge.delete_cell(cell_id)
            _emit_all_cells(bridge, relay)
            return JSONResponse({"ok": True, "cell_id": cell_id})
        except Exception as e:
            logger.error(f"delete_cell error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/cell/{cell_id}/hide-code", methods=["POST"])
    async def toggle_hide_code(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)

        try:
            data = await request.json()
            hide_code = data.get("hide_code", False)
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        try:
            await bridge.set_cell_config(cell_id, hide_code=hide_code)
            await bridge.save()
            return JSONResponse({"ok": True, "cell_id": cell_id, "hide_code": hide_code})
        except Exception as e:
            logger.error(f"toggle_hide_code error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/cell/{cell_id}/type", methods=["POST"])
    async def set_cell_type(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)

        try:
            data = await request.json()
            cell_type = data.get("cell_type", "code")
            code = data.get("code", "")
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        if cell_type not in ("code", "markdown"):
            return JSONResponse({"error": "Invalid cell_type. Must be 'code' or 'markdown'"}, status_code=400)

        try:
            if bridge.get_cell(cell_id):
                bridge.update_cell(cell_id, code=code, is_markdown=(cell_type == "markdown"))
                await bridge.save()
            else:
                logger.debug(f"set_cell_type: {cell_id} not in bridge yet (pre-run)")
            return JSONResponse({"ok": True, "cell_id": cell_id, "cell_type": cell_type})
        except Exception as e:
            logger.error(f"set_cell_type error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/sync", methods=["POST"])
    async def sync_signals(request: Request) -> JSONResponse:
        try:
            signals = (await request.json()).get("signals", {})
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        if not signals:
            return JSONResponse({"ok": True, "synced": []})
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)

        try:
            synced = []
            for name, value in signals.items():
                if name == "auto_run_stale":
                    bridge.auto_run_stale = bool(value)
                else:
                    await bridge.set_input(name, value)
                synced.append(name)

            input_signals = [n for n in synced if n != "auto_run_stale"]
            if input_signals and bridge.auto_run_stale:
                await bridge.run_stale_cells_coalesced()

            return JSONResponse({"ok": True, "synced": synced})
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/run/{cell_id}", methods=["POST"])
    async def run_cell(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        relay = _get_relay(request)

        try:
            code = str((await request.json()).get("code", ""))
        except Exception:
            return JSONResponse({"error": "Invalid request body"}, status_code=400)

        if not code.strip():
            if bridge.get_cell(cell_id):
                await bridge.run_cell(cell_id, code="")
                bridge.clear_cell_output(cell_id)
            relay.emit_element("", f"#output-content-{cell_id}", mode="inner")
            relay.emit_signals({f"{cell_id}_status": "", f"{cell_id}_time": ""})
            return JSONResponse({"ok": True, "cell_id": cell_id, "cleared": True})

        code = fixed_dedent(code)

        try:
            existed = bridge.get_cell(cell_id) is not None
            if existed:
                await bridge.run_cell(cell_id, code=code)
            elif is_markdown(code):
                await bridge.add_cell(code, cell_id=cell_id)
            else:
                await bridge.add_ui_cell(code, cell_id=cell_id)

            relay.emit_signals({
                f"{cell_id}_status": "running",
                f"{cell_id}_time": "",
            })
            return JSONResponse({"ok": True, "cell_id": cell_id, "existed": existed})
        except Exception as e:
            logger.error(f"run_cell error: {e}")
            relay.emit_signals({
                f"{cell_id}_status": "error",
                f"{cell_id}_time": "",
            })
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/run-all", methods=["POST"])
    async def run_all(request: Request) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        try:
            await bridge.run_all_cells()
            return JSONResponse({"ok": True, "cells": list(bridge.cells.keys())})
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/run-stale", methods=["POST"])
    async def run_stale(request: Request) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        try:
            await bridge.run_stale_cells()
            return JSONResponse({"ok": True})
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/variables", methods=["GET"])
    async def get_variables(request: Request) -> JSONResponse:
        if not (bridge := _get_bridge(request)):
            return JSONResponse({"variables": {}, "connected": False, "ready": False})
        return JSONResponse({"variables": bridge.variables, "connected": bridge.connected, "ready": bridge.ready})

    @router("/status", methods=["GET"])
    async def get_status(request: Request) -> JSONResponse:
        if not (bridge := _get_bridge(request)):
            return JSONResponse({"connected": False, "ready": False, "cells": 0, "variables": []})
        return JSONResponse({
            "connected": bridge.connected,
            "ready": bridge.ready,
            "cells": len(bridge.cells),
            "variables": list(bridge.variables.keys()),
        })

    @router("/cells", methods=["GET"])
    async def get_cells(request: Request) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        return JSONResponse({
            "cells": [
                {"id": cid, "code": c.code, "status": c.status, "execution_time": c.execution_time, "error": c.error}
                for cid, c in bridge.cells.items()
            ]
        })

    @router("/save", methods=["POST"])
    async def save_notebook(request: Request) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)

        try:
            body = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
            codes = body.get("codes", {})
            cells = bridge.cells
            for cell_id, code in codes.items():
                if cell_id in cells:
                    bridge.update_cell(cell_id, code=code)

            await bridge.save()
            return JSONResponse({"ok": True, "cells": len(bridge.cells)})
        except ValueError as e:
            logger.warning(f"save validation error: {e}")
            return JSONResponse({"error": str(e)}, status_code=400)
        except Exception:
            logger.exception("save error")
            return JSONResponse({"error": "Save failed"}, status_code=500)

    def _route_cell_output(relay, cell_id, cell, num_map):
        if not (cell.output and isinstance(cell.output, dict)):
            return
        content = renderer.render_output_content(
            cell.output.get("mimetype", "text/plain"),
            cell.output.get("data", ""),
            cell.output.get("channel"),
            cell_id=cell_id,
        )
        target = cell.output_target
        if target:
            relay.emit_element(_annex_attribution(cell_id, num_map.get(cell_id)), f"#output-annex-{target}", mode="inner")
            relay.emit_element(content, f"#output-annex-{target}", mode="append")
            relay.emit_element("", f"#output-content-{cell_id}", mode="inner")
        else:
            relay.emit_element(content, f"#output-content-{cell_id}", mode="inner")

    def _emit_all_cells(bridge_inst, relay, autofocus_cell: str | None = None) -> None:
        """Re-render all user cells in current _cells dict order via SSE."""
        renderer.reset_cell_counter()
        cells = bridge_inst.cells
        user_cells = [(name, cell) for name, cell in cells.items() if not name.startswith("_starimo_")]
        total = len(user_cells)
        all_cell_info = [(name, i + 1) for i, (name, _) in enumerate(user_cells)]

        parts = []
        for name, cell in user_cells:
            display_code = (unwrap_markdown(cell.code) or cell.code) if cell.is_markdown else cell.code
            cell_html = renderer.render_editable_cell(
                name, display_code, cell.hide_code,
                is_markdown=cell.is_markdown,
                total_cells=total, all_cells=all_cell_info,
                note=cell.note, output_target=cell.output_target,
                autofocus=(name == autofocus_cell),
            )
            parts.append(cell_html)

        html = "\n".join(str(to_xml(p)) for p in parts)
        relay.emit_element(html, f"#{CELLS_CONTAINER_ID}", mode="inner")

        # mode="inner" above replaced cell structures; output targets child IDs so must re-emit separately
        num_map = dict(all_cell_info)
        for name, cell in user_cells:
            _route_cell_output(relay, name, cell, num_map)

    @router("/cell/{cell_id}/move", methods=["POST"])
    async def move_cell(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        relay = _get_relay(request)

        try:
            data = await request.json()
            position = int(data["position"])
        except (KeyError, TypeError, ValueError):
            return JSONResponse({"error": "Missing or invalid 'position'"}, status_code=400)
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        try:
            bridge.move_cell(cell_id, position)
            _emit_all_cells(bridge, relay)
            return JSONResponse({"ok": True})
        except ValueError as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        except Exception as e:
            logger.error(f"move_cell error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/cell/{cell_id}/output-target", methods=["POST"])
    async def set_output_target(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        relay = _get_relay(request)

        try:
            data = await request.json()
            target = data.get("target")
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        try:
            cell = bridge.get_cell(cell_id)
            old_target = cell.output_target if cell else None
            bridge.update_cell(cell_id, output_target=target or None)

            display = f"\u2192 {target}" if target else ""
            relay.emit_element(
                Span(display, cls="output-target-display"),
                f"#cell-{cell_id} .output-target-display",
                mode="outer",
            )

            # Move output HTML instantly (no rerun needed)
            if cell:
                num_map = {}
                if target:
                    uc = [(n, c) for n, c in bridge.cells.items() if not n.startswith("_starimo_")]
                    num_map = {n: i + 1 for i, (n, _) in enumerate(uc)}
                _route_cell_output(relay, cell_id, cell, num_map)

            # Clear old target's annex if redirecting away
            if old_target and old_target != target:
                relay.emit_element("", f"#output-annex-{old_target}", mode="inner")

            return JSONResponse({"ok": True})
        except ValueError as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        except Exception as e:
            logger.error(f"set_output_target error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/cell/{cell_id}/note", methods=["POST"])
    async def set_note(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)

        try:
            data = await request.json()
            note = data.get("note", "").strip()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        try:
            bridge.set_note(cell_id, note or None)
            await bridge.save()
            return JSONResponse({"ok": True})
        except ValueError as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        except Exception as e:
            logger.error(f"set_note error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

    @router("/cell/{cell_id}/rename", methods=["POST"])
    async def rename_cell(request: Request, cell_id: str) -> JSONResponse:
        if not (bridge := _get_bridge(request)) or not bridge.connected:
            return JSONResponse({"error": "Not connected"}, status_code=503)
        relay = _get_relay(request)

        try:
            data = await request.json()
            raw_name = data.get("name", "").strip()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

        new_name = normalize_cell_name(raw_name)
        if not new_name:
            return JSONResponse({"error": "Name cannot be empty after normalization"}, status_code=400)

        try:
            bridge.rename_cell(cell_id, new_name)
            _emit_all_cells(bridge, relay)
            await bridge.save()
            return JSONResponse({"ok": True, "new_id": new_name})
        except ValueError as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        except Exception as e:
            logger.error(f"rename_cell error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

    return router


__all__ = ["create_starimo_router"]
