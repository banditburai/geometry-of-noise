import asyncio
import atexit
import json
import logging
import os
import signal
import socket
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

PID_FILE = Path.home() / ".starimo" / "pids.json"
LOG_DIR = PID_FILE.parent / "logs"
STARTUP_TIMEOUT = 30.0


def _is_marimo_process(pid: int) -> bool:
    """Guard against PID reuse — only kill if the process is actually marimo."""
    try:
        result = subprocess.run(
            ["ps", "-p", str(pid), "-o", "args="],
            capture_output=True, text=True, timeout=2,
        )
        return "marimo" in result.stdout
    except Exception:
        return False


def _terminate_process(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=2.0)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=1.0)


@dataclass
class NotebookProcess:
    notebook_path: Path
    port: int
    process: subprocess.Popen


@dataclass
class StarimoSpawner:
    """Manages marimo notebook processes with orphan cleanup and graceful shutdown."""

    base_port: int = 2719

    _processes: dict[str, NotebookProcess] = field(default_factory=dict)
    _next_port: int = field(init=False)
    _port_lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    def __post_init__(self):
        self._next_port = self.base_port
        self._kill_orphaned_processes()
        atexit.register(self._sync_cleanup)

    def _load_pids(self) -> dict[str, int]:
        if not PID_FILE.exists():
            return {}
        try:
            return json.loads(PID_FILE.read_text())
        except Exception:
            return {}

    def _save_pids(self) -> None:
        pids = {nid: proc.process.pid for nid, proc in self._processes.items()}
        PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(json.dumps(pids))

    def _kill_orphaned_processes(self) -> None:
        for notebook_id, pid in self._load_pids().items():
            if not _is_marimo_process(pid):
                logger.debug(f"Orphan PID {pid} ({notebook_id}) not a marimo process, skipping")
                continue
            try:
                os.kill(pid, signal.SIGTERM)
                logger.info(f"Killed orphan {notebook_id} (PID {pid})")
            except (ProcessLookupError, PermissionError):
                pass

        if PID_FILE.exists():
            PID_FILE.unlink()

    def _sync_cleanup(self) -> None:
        """Atexit handler — must be synchronous."""
        for notebook_id, proc_info in list(self._processes.items()):
            _terminate_process(proc_info.process)
            logger.info(f"Stopped {notebook_id} (port {proc_info.port})")
        self._processes.clear()
        if PID_FILE.exists():
            PID_FILE.unlink()

    async def _allocate_port(self) -> int:
        async with self._port_lock:
            for _ in range(100):
                port = self._next_port
                self._next_port += 1
                try:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                        s.bind(("127.0.0.1", port))
                        return port
                except OSError:
                    continue
            raise RuntimeError("No available port after 100 attempts")

    async def _wait_for_ready(
        self, port: int, proc: subprocess.Popen, timeout: float = STARTUP_TIMEOUT,
    ) -> None:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        last_error: Exception | None = None

        async with httpx.AsyncClient() as client:
            while loop.time() < deadline:
                if proc.poll() is not None:
                    raise RuntimeError(
                        f"Process exited with code {proc.returncode} before becoming ready"
                    )
                try:
                    resp = await client.get(f"http://127.0.0.1:{port}", timeout=2.0)
                    if resp.status_code == 200:
                        return
                except Exception as e:
                    last_error = e
                await asyncio.sleep(0.5)

        raise TimeoutError(f"Marimo did not start within {timeout}s on port {port}: {last_error}")

    async def spawn(
        self,
        notebook_id: str,
        notebook_path: str,
        force_restart: bool = False,
    ) -> dict[str, Any]:
        path = Path(notebook_path)
        if not path.exists():
            raise FileNotFoundError(f"Notebook not found: {notebook_path}")

        existing = self._processes.get(notebook_id)
        if existing and existing.process.poll() is None:
            if force_restart:
                await self.kill(notebook_id)
            elif existing.notebook_path == path:
                return {"port": existing.port, "status": "reused",
                        "notebook_id": notebook_id, "notebook_path": str(path)}
            else:
                await self.kill(notebook_id)

        port = await self._allocate_port()
        cmd = [
            sys.executable, "-m", "marimo", "edit",
            str(path), "--headless", "--no-token", "--watch",
            "--host", "127.0.0.1", "--port", str(port),
            "--allow-origins", "*",
        ]

        LOG_DIR.mkdir(parents=True, exist_ok=True)
        stderr_log = open(LOG_DIR / f"{notebook_id}.log", "w")

        logger.info(f"Spawning marimo for {notebook_id} on port {port}")
        process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=stderr_log)
        stderr_log.close()  # child process has its own fd

        self._processes[notebook_id] = NotebookProcess(
            notebook_path=path, port=port, process=process,
        )
        self._save_pids()

        try:
            await self._wait_for_ready(port, process)
        except (TimeoutError, RuntimeError) as e:
            _terminate_process(process)
            log_path = LOG_DIR / f"{notebook_id}.log"
            if log_path.exists():
                stderr_content = log_path.read_text().strip()
                if stderr_content:
                    logger.error(f"Marimo stderr for {notebook_id}:\n{stderr_content}")
            del self._processes[notebook_id]
            self._save_pids()
            raise RuntimeError(f"Failed to start marimo for {notebook_id}: {e}")

        return {"port": port, "status": "started",
                "notebook_id": notebook_id, "notebook_path": str(path)}

    async def kill(self, notebook_id: str) -> dict[str, Any]:
        if notebook_id not in self._processes:
            return {"status": "not_found", "notebook_id": notebook_id}

        proc_info = self._processes.pop(notebook_id)
        _terminate_process(proc_info.process)
        self._save_pids()
        return {"status": "killed", "notebook_id": notebook_id}

    async def status(self, notebook_id: str | None = None) -> dict[str, Any]:
        if notebook_id:
            if notebook_id not in self._processes:
                return {"status": "not_found", "notebook_id": notebook_id}
            p = self._processes[notebook_id]
            return {"notebook_id": notebook_id, "port": p.port,
                    "running": p.process.poll() is None, "notebook_path": str(p.notebook_path)}

        return {"notebooks": {
            nid: {"port": p.port, "running": p.process.poll() is None,
                  "notebook_path": str(p.notebook_path)}
            for nid, p in self._processes.items()
        }}

    async def cleanup(self) -> None:
        for notebook_id in list(self._processes):
            await self.kill(notebook_id)


def create_spawner_app(spawner: StarimoSpawner):
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse
    from starlette.routing import Route

    async def spawn_handler(request):
        try:
            body = await request.json()
            notebook_id = body.get("notebook_id")
            notebook_path = body.get("notebook_path")
            if not notebook_id or not notebook_path:
                return JSONResponse({"error": "notebook_id and notebook_path required"}, status_code=400)
            result = await spawner.spawn(notebook_id, notebook_path, body.get("force_restart", False))
            return JSONResponse(result)
        except FileNotFoundError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except Exception as e:
            logger.exception("Spawn error")
            return JSONResponse({"error": str(e)}, status_code=500)

    async def kill_handler(request):
        try:
            body = await request.json()
            notebook_id = body.get("notebook_id")
            if not notebook_id:
                return JSONResponse({"error": "notebook_id required"}, status_code=400)
            return JSONResponse(await spawner.kill(notebook_id))
        except Exception as e:
            logger.exception("Kill error")
            return JSONResponse({"error": str(e)}, status_code=500)

    async def status_handler(request):
        try:
            return JSONResponse(await spawner.status(request.query_params.get("notebook_id")))
        except Exception as e:
            logger.exception("Status error")
            return JSONResponse({"error": str(e)}, status_code=500)

    return Starlette(
        routes=[
            Route("/spawn", spawn_handler, methods=["POST"]),
            Route("/kill", kill_handler, methods=["POST"]),
            Route("/status", status_handler, methods=["GET"]),
            Route("/health", lambda _: JSONResponse({"status": "ok"}), methods=["GET"]),
        ],
        on_shutdown=[spawner.cleanup],
    )


__all__ = ["StarimoSpawner", "create_spawner_app"]
