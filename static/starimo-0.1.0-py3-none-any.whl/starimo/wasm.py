import asyncio
import json
import logging
import sys
import uuid
from typing import TYPE_CHECKING, Any, Callable

from .core import (
    STARIMO_PREAMBLE_NAME,
    STARIMO_SEED_BOOTSTRAP_CODE,
    STARIMO_SEED_NAME,
    STARIMO_UI_PREAMBLE_CODE,
    CellInfo,
    SeedCellGuard,
    SignalRegistry,
    call_setter,
    extract_starimo_values,
    find_seed_cell,
    is_markdown,
    parse_variable_value,
    unwrap_markdown,
)

if TYPE_CHECKING:
    from marimo._pyodide.pyodide_session import PyodideBridge, PyodideSession

logger = logging.getLogger(__name__)

__all__ = ["WasmBridge", "is_pyodide", "init_kernel"]

_warned_no_callback = False


def is_pyodide() -> bool:
    return "pyodide" in sys.modules or sys.platform == "emscripten"


def _safe_json_value(value: Any) -> str | int | float | bool | None:
    """Convert to primitive type safe for Pyodide->JS interop. Complex types become JSON strings."""
    if value is None:
        return None

    if hasattr(value, "to_py"):
        try:
            value = value.to_py()
        except Exception:
            return str(value)

    if isinstance(value, (bool, int, float, str)):
        return value

    if hasattr(value, "data") and hasattr(value, "mimetype"):
        try:
            return json.dumps({"mimetype": str(getattr(value, "mimetype", "text/plain")), "data": str(getattr(value, "data", ""))})
        except Exception:
            return str(getattr(value, "data", ""))

    try:
        return json.dumps(value)
    except (TypeError, ValueError):
        return str(value)


def _rewrite_assignment(code: str, name: str, value: Any) -> str | None:
    """Replace `name = <old>` with `name = <value>` at the top level.

    Used by set_input() to inject fresh frontend values into the seed cell's
    source when stardust's codegen produced a hardcoded assignment. Returns
    None if no top-level assignment for ``name`` is present.
    """
    import re

    lit = repr(value)
    pattern = re.compile(rf"^(\s*){re.escape(name)}\s*=\s*[^\n]+$", re.MULTILINE)
    if not pattern.search(code):
        return None
    return pattern.sub(lambda m: f"{m.group(1)}{name} = {lit}", code, count=1)


def _store_code(code: str) -> tuple[str, bool]:
    """Return (stored_code, is_md) -- unwraps mo.md() for clean storage."""
    is_md = is_markdown(code)
    if is_md:
        raw = unwrap_markdown(code)
        if raw is not None:
            return raw, True
    return code, is_md


def _dig(obj: Any, *attrs: str, default: Any = None) -> Any:
    """Chase a chain of getattr calls, returning default if any is None."""
    for attr in attrs:
        if obj is None:
            return default
        obj = getattr(obj, attr, None)
    return obj if obj is not None else default


class WasmBridge:
    """Cells keyed by function name; separate mapping tracks function_name -> runtime_id."""

    def __init__(
        self,
        notebook_path: str,
        signal_callback: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.notebook_path = notebook_path
        self._raw_signal_callback = signal_callback or (lambda _: None)
        self.session: PyodideSession | None = None
        self.bridge: PyodideBridge | None = None
        self._ready = False
        self._signal_registry = SignalRegistry()
        self._cells: dict[str, CellInfo] = {}
        self._name_to_runtime_id: dict[str, str] = {}
        self._runtime_id_to_name_map: dict[str, str] = {}
        self._output_variables: set[str] = set()
        self._cells_awaiting_output: set[str] = set()
        self._pending_cell_updates: dict[str, Any] = {}
        self._pending_cell_outputs: dict[str, Any] = {}
        self._flush_scheduled = False
        self._preamble_cell_id: str | None = None
        self._seed_guard: SeedCellGuard | None = None
        self._seed_initialized = False
        self.auto_run_stale = True
        self.on_cell_output: Callable[[str, dict], None] | None = None

    @property
    def ready(self) -> bool:
        return self._ready

    def signal_callback(self, updates: dict[str, Any]) -> None:
        self._raw_signal_callback(updates)

    # ── ID mapping helpers ────────────────────────────────────────────

    def _register_cell_id(self, name: str, runtime_id: str) -> None:
        self._name_to_runtime_id[name] = runtime_id
        self._runtime_id_to_name_map[runtime_id] = name

    def _unregister_cell_id(self, name: str) -> None:
        rid = self._name_to_runtime_id.pop(name, None)
        if rid:
            self._runtime_id_to_name_map.pop(rid, None)

    def _resolve_name(self, runtime_id: str | None) -> str | None:
        if not runtime_id:
            return None
        rid = str(runtime_id)
        if rid in self._runtime_id_to_name_map:
            return self._runtime_id_to_name_map[rid]
        if rid in self._cells:
            return rid
        return None

    # ── Initialization ──────────────────────────────────────────────

    async def initialize(self) -> None:
        if not is_pyodide():
            raise RuntimeError("WasmBridge requires Pyodide environment")

        from marimo._pyodide.bootstrap import create_session, instantiate

        logger.info(f"Initializing kernel for {self.notebook_path}")

        self.session, self.bridge = create_session(
            filename=self.notebook_path,
            query_params={},
            message_callback=self._on_kernel_message,
            user_config={},  # type: ignore[arg-type]
        )

        if self.session is None:
            raise RuntimeError("Failed to create Pyodide session")

        instantiate(self.session, auto_instantiate=True)
        task = asyncio.create_task(self.session.start())
        task.add_done_callback(self._on_start_done)
        logger.info("Kernel started, waiting for kernel-ready")

        # Load cells NOW (session is assigned, notebook is parsed) and schedule
        # initial run. Doing this inside _handle_kernel_ready loses the race —
        # marimo fires kernel-ready from inside create_session() before the
        # returned tuple lands in self.session.
        self._load_cells_and_kick()

    @staticmethod
    def _on_start_done(task: asyncio.Task) -> None:
        if task.exception():
            logger.error(f"Kernel start failed: {task.exception()}")

    # ── Kernel message handling ─────────────────────────────────────

    def _on_kernel_message(self, msg_json: str) -> None:
        try:
            msg = json.loads(msg_json)
        except json.JSONDecodeError:
            logger.warning(f"Invalid JSON: {msg_json[:100]}")
            return

        op = msg.get("op")
        data = msg.get("data", {})

        match op:
            case "kernel-ready":
                self._handle_kernel_ready(data)
            case "cell-op":
                self._handle_cell_op(data)
            case "variable-values":
                # Marimo's `variable-values` carries the actual values.
                # The separate `variables` op is just dependency-graph
                # metadata (declared_by / used_by) with NO value — feeding
                # it through _handle_variable_values would mergePatch every
                # signal to null, which clobbers the reactive bindings.
                self._handle_variable_values(data)
            case "variables":
                pass
            case "completed-run":
                pass

    def _handle_kernel_ready(self, _data: dict) -> None:
        # NOTE: marimo can fire kernel-ready from INSIDE create_session, before
        # the returned tuple is assigned to self.session. So self.session may
        # be None here. Cell loading and initial run happen at the end of
        # initialize() (see _load_cells_and_kick), where self.session is
        # guaranteed to be set.
        self._ready = True
        logger.info("Kernel ready message received (cell load deferred to initialize)")
        self.signal_callback({"starimo_ready": True, "starimo_status": "connected"})

    def _load_cells_and_kick(self) -> None:
        """Populate cell metadata from session + kick initial run.

        Called at the end of initialize() — at that point self.session is
        assigned and the notebook's cell_manager has parsed the notebook.
        """
        all_defs: set[str] = set()
        all_refs: set[str] = set()

        if self.session is None:
            logger.warning("_load_cells_and_kick: session is None (shouldn't happen)")
            return

        try:
            cell_manager = self.session.app_manager.app.cell_manager
            for runtime_id, cell in cell_manager.valid_cells():
                # Both generated notebook cells are `def __(): ...` — so the
                # public `cell.name` collides across cells. Use `runtime_id`
                # (the cell_id from valid_cells) as the unique key.
                name = str(runtime_id)
                code = cell._cell.code
                hide_code = _dig(cell._cell, 'config', 'hide_code', default=False)

                stored_code, is_md = _store_code(code)
                cell_defs = set(cell.defs)
                self._cells[name] = CellInfo(
                    id=name, code=stored_code, name=name,
                    hide_code=hide_code, is_markdown=is_md, defs=cell_defs,
                )
                self._register_cell_id(name, runtime_id)

                all_defs.update(cell_defs)
                all_refs.update(cell.refs)

            seed_cell = find_seed_cell(self._cells)
            seed_signals = set()
            if seed_cell and seed_cell.code:
                seed_signals = set(extract_starimo_values(seed_cell.code).keys())
                self._seed_guard = SeedCellGuard(seed_cell.id)
            self._output_variables = (all_defs - all_refs) - seed_signals

        except Exception as e:
            logger.warning(f"Could not access cell metadata from session: {e}")
            self._output_variables = set()

        logger.info(f"[starimo] Loaded {len(self._cells)} cells, scheduling initial run")
        try:
            asyncio.ensure_future(self._kick_initial_run())
        except RuntimeError as e:
            logger.warning(f"No running event loop for initial cell run: {e}")

    async def _kick_initial_run(self) -> None:
        """Dispatch first cell execution after kernel-ready."""
        try:
            await self.run_all_cells()
        except Exception as exc:
            logger.error(f"Initial cell run failed: {exc}")

    def _handle_cell_op(self, data: dict) -> None:
        runtime_id = data.get("cell_id")
        status = data.get("status")
        output = data.get("output")

        name = self._resolve_name(runtime_id)
        if not name or name not in self._cells:
            return

        cell = self._cells[name]
        if status:
            cell.status = str(status)
            self._pending_cell_updates[f"{name}_status"] = cell.status
            if status in ("running", "queued"):
                self._cells_awaiting_output.add(name)

        if output is not None:
            self._cells_awaiting_output.discard(name)
            # Marimo JSON-encodes mimebundle data (e.g. matplotlib) -- deserialize at transport layer
            if isinstance(output, dict) and output.get("mimetype") == "application/vnd.marimo+mimebundle":
                raw = output.get("data")
                if isinstance(raw, str):
                    try:
                        output = {**output, "data": json.loads(raw)}
                    except (json.JSONDecodeError, TypeError):
                        pass
            cell.output = output
            if self.on_cell_output:
                self.on_cell_output(name, output)
            else:
                self._pending_cell_outputs[name] = output
        elif status == "idle" and name in self._cells_awaiting_output:
            # Cell finished running without producing output -- clear stale output
            self._cells_awaiting_output.discard(name)
            if cell.output is not None:
                cell.output = None
                if self.on_cell_output:
                    self.on_cell_output(name, {"data": "", "mimetype": "text/plain"})

        # Emit execution time (empty string clears stale values)
        self._pending_cell_updates[f"{name}_time"] = ""

        if (self._pending_cell_updates or self._pending_cell_outputs) and not self._flush_scheduled:
            self._schedule_flush()

    def _schedule_flush(self) -> None:
        if self._flush_scheduled:
            return
        self._flush_scheduled = True
        try:
            loop = asyncio.get_running_loop()
            loop.call_soon(self._flush_cell_updates)
        except RuntimeError:
            self._flush_cell_updates()

    def _flush_cell_updates(self) -> None:
        self._flush_scheduled = False

        if self._pending_cell_updates:
            updates = self._pending_cell_updates.copy()
            self._pending_cell_updates.clear()
            self.signal_callback(updates)

        if self._pending_cell_outputs:
            outputs = self._pending_cell_outputs.copy()
            self._pending_cell_outputs.clear()
            self._render_cell_outputs(outputs)

    def _render_cell_outputs(self, outputs: dict[str, Any]) -> None:
        """Fallback when on_cell_output is not set -- renders directly into DOM."""
        try:
            from js import document  # type: ignore[import-not-found]
            from starimo.renderer import DefaultRenderer
            from fastcore.xml import to_xml

            renderer = DefaultRenderer()

            for name, output in outputs.items():
                try:
                    if isinstance(output, dict):
                        mimetype = output.get("mimetype", "text/plain")
                        data = output.get("data", "")
                        channel = output.get("channel")
                    else:
                        mimetype = "text/plain"
                        data = str(output)
                        channel = None

                    content = renderer.render_output_content(mimetype, data, channel)
                    html = to_xml(content)

                    container = document.querySelector(f"#output-content-{name}")
                    if container is None:
                        # Headless apps mount output containers under user-
                        # facing names (the variables a cell defines), not the
                        # opaque runtime cell_id. Try each def in turn.
                        cell_meta = self._cells.get(name)
                        if cell_meta is not None:
                            for def_name in cell_meta.defs:
                                container = document.querySelector(f"#output-content-{def_name}")
                                if container is not None:
                                    break
                    if container:
                        container.innerHTML = html

                except Exception as e:
                    logger.warning(f"Failed to render output for {name}: {e}")
        except ImportError:
            logger.warning("DOM API not available for output rendering")

    def _handle_variable_values(self, data: dict) -> None:
        variables = data.get("variables", [])
        updates: dict[str, Any] = {}

        for var_info in variables:
            name = var_info.get("name")
            if not name or name.startswith("_"):
                continue

            datatype = var_info.get("datatype", "")
            if datatype in ("function", "type", "module", "builtin_function_or_method"):
                continue

            raw_value = var_info.get("value")
            # Object-repr strings (e.g. <Foo object at 0x123>) aren't useful data.
            # Their values reach the browser through cell-output HTML, not signals.
            if isinstance(raw_value, str) and raw_value.startswith("<") and " object at 0x" in raw_value:
                continue

            parsed = _safe_json_value(parse_variable_value(raw_value))
            if self._signal_registry.set_without_pending(name, parsed):
                updates[name] = parsed

        if updates:
            self.signal_callback(updates)

    # ── Signal sync ─────────────────────────────────────────────────

    async def set_input(self, datastar_name: str, value: Any) -> None:
        if datastar_name in self._output_variables:
            return

        call_setter(datastar_name, value)
        self._signal_registry.update(datastar_name, value)

        # WASM-mode fallback: stardust's generated notebook hardcodes seed
        # values (`n = 0`) rather than using `mo.state`, so no Python setter
        # was registered for this name. Find whichever cell defines the
        # variable, rewrite its code to reflect the new value, then re-run
        # all cells so dependents (like `doubled`) recompute.
        owner = next(
            (c for c in self._cells.values() if datastar_name in c.defs),
            None,
        )
        if owner is not None:
            new_code = _rewrite_assignment(owner.code, datastar_name, value)
            if new_code is not None:
                owner.code = new_code
                self._execute_cells(list(self._cells.keys()))

    # ── Cell operations ─────────────────────────────────────────────

    def _execute_cells(self, names: list[str]) -> None:
        if not self.bridge:
            raise RuntimeError("Bridge not initialized")
        runtime_ids = [self._name_to_runtime_id.get(n) or n for n in names]
        codes = [self._cells[n].code for n in names]
        self.bridge.put_control_request(json.dumps({
            "type": "execute-cells",
            "cellIds": runtime_ids,
            "codes": codes,
        }))

    async def run_all_cells(self) -> None:
        names = list(self._cells.keys())
        if self._seed_guard:
            names = self._seed_guard.filter_cells(names)
        self._execute_cells(names)

    async def run_stale_cells(self) -> None:
        """Send all non-seed cells to marimo; marimo handles staleness detection."""
        await self.run_all_cells()

    async def run_stale_cells_coalesced(self) -> None:
        """No coalescing needed in WASM (single-threaded event loop)."""
        await self.run_all_cells()

    async def run_cell(self, name: str, code: str | None = None) -> None:
        if not self.bridge:
            raise RuntimeError("Bridge not initialized")

        if self._seed_guard:
            self._seed_guard.check_cell(name, "run")

        if code is not None and name in self._cells:
            self._cells[name].code = code

        self._execute_cells([name])

    def update_cell(self, name: str, code: str | None = None, is_markdown: bool | None = None) -> None:
        if name not in self._cells:
            raise ValueError(f"Unknown cell: {name}")
        if code is not None:
            self._cells[name].code = code
        if is_markdown is not None:
            self._cells[name].is_markdown = is_markdown

    async def add_cell(self, code: str, cell_id: str | None = None) -> str:
        if not self.bridge:
            raise RuntimeError("Bridge not initialized")

        cell_id = cell_id or f"cell_{uuid.uuid4().hex[:8]}"
        stored_code, is_md = _store_code(code)
        self._cells[cell_id] = CellInfo(
            id=cell_id, code=stored_code, name=cell_id, is_markdown=is_md,
        )
        self._register_cell_id(cell_id, cell_id)
        self._execute_cells([cell_id])
        return cell_id

    async def add_ui_cell(self, code: str, cell_id: str | None = None) -> str:
        await self._ensure_ui_preamble()
        return await self.add_cell(code, cell_id=cell_id)

    async def delete_cell(self, name: str) -> None:
        self._unregister_cell_id(name)
        self._cells.pop(name, None)

    async def set_cell_config(self, name: str, *, hide_code: bool | None = None) -> None:
        if name not in self._cells:
            raise ValueError(f"Unknown cell: {name}")
        if hide_code is not None:
            self._cells[name].hide_code = hide_code

    def clear_cell_output(self, cell_id: str) -> None:
        cell = self._cells.get(cell_id)
        if cell:
            cell.output = None

    async def install_package(self, package: str) -> dict:
        return {"success": False, "error": "Package install not supported in WASM mode"}

    async def save(self) -> str:
        raise NotImplementedError("Save not supported in WASM mode")

    async def _ensure_ui_preamble(self) -> str:
        if self._preamble_cell_id is None and STARIMO_PREAMBLE_NAME not in self._cells:
            logger.info("Creating UI preamble cell")
            await self.add_cell(STARIMO_UI_PREAMBLE_CODE, cell_id=STARIMO_PREAMBLE_NAME)
        self._preamble_cell_id = STARIMO_PREAMBLE_NAME
        return STARIMO_PREAMBLE_NAME

    async def _ensure_seed_cell(self) -> str | None:
        if self._seed_guard is not None:
            return self._seed_guard.seed_name
        if STARIMO_SEED_NAME in self._cells:
            self._seed_guard = SeedCellGuard(STARIMO_SEED_NAME)
            return STARIMO_SEED_NAME
        logger.info("Creating bootstrap seed cell")
        await self.add_cell(STARIMO_SEED_BOOTSTRAP_CODE, cell_id=STARIMO_SEED_NAME)
        self._seed_guard = SeedCellGuard(STARIMO_SEED_NAME)
        self._seed_initialized = True
        return STARIMO_SEED_NAME

    async def initialize_seed_cell(self) -> bool:
        if not self.bridge:
            raise RuntimeError("Bridge not initialized")

        if self._seed_initialized:
            return False

        if not self._seed_guard:
            return False

        seed_name = self._seed_guard.seed_name
        if seed_name not in self._cells:
            logger.warning(f"Seed cell {seed_name} not found")
            return False

        logger.info(f"Initializing seed cell: {seed_name}")
        self._execute_cells([seed_name])

        self._seed_initialized = True
        return True

    # ── Properties ──────────────────────────────────────────────────

    @property
    def variables(self) -> dict[str, Any]:
        return self._signal_registry.get_all()

    @property
    def connected(self) -> bool:
        return self._ready

    def get_cell(self, cell_id: str) -> CellInfo | None:
        return self._cells.get(cell_id)

    @property
    def cells(self) -> dict[str, CellInfo]:
        return self._cells.copy()

    async def disconnect(self) -> None:
        self._ready = False


# ── Standalone WASM init (called by Stardust's runtime.js) ──────────

async def init_kernel(notebook_path: str) -> None:
    """Entry point for Stardust runtime -- init marimo in Pyodide/WASM."""
    if not is_pyodide():
        raise RuntimeError("init_kernel requires Pyodide environment")

    import js

    global _warned_no_callback

    def signal_callback(updates: dict[str, Any]) -> None:
        global _warned_no_callback

        try:
            has_callback = js.window.__stardust__ and js.window.__stardust__.starimo
        except Exception:
            has_callback = False

        if has_callback:
            for name, value in updates.items():
                try:
                    safe_value = _safe_json_value(value)

                    # Pyodide->JS via eval avoids JsProxy conversion issues
                    import pyodide.code
                    js_code = f"window.__stardust__.starimo.onSignalUpdate({json.dumps(name)}, {json.dumps(safe_value)})"
                    pyodide.code.run_js(js_code)
                except Exception as e:
                    logger.warning(f"Signal callback error for {name}={value!r}: {e}")
        elif not _warned_no_callback:
            logger.warning("No JS callback at __stardust__.starimo")
            _warned_no_callback = True

    logger.info(f"Loading notebook from {notebook_path}")
    bridge = WasmBridge(notebook_path=notebook_path, signal_callback=signal_callback)
    await bridge.initialize()

    max_wait = 30
    wait_interval = 0.1
    waited = 0.0
    while not bridge.ready and waited < max_wait:
        await asyncio.sleep(wait_interval)
        waited += wait_interval

    if not bridge.ready:
        logger.warning(f"Kernel did not become ready within {max_wait}s")

    stardust = getattr(js.window, "__stardust__", None)
    starimo_ns = getattr(stardust, "starimo", None) if stardust else None
    if starimo_ns:
        starimo_ns.bridge = bridge
        logger.info(f"Kernel initialized (ready={bridge.ready})")
    else:
        js.window.__STARIMO_BRIDGE__ = bridge
        logger.warning("Using legacy global (no __stardust__ namespace)")
