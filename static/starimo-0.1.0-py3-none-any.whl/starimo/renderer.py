"""Default cell renderer for Starimo notebooks."""


import html as html_module
import json
import re
from typing import Any

from fastcore.xml import NotStr
from starhtml import (
    Button, Div, Img, Pre, Span, Strong, Table, Tbody, Td, Textarea, Th, Thead, Tr,
)
from starhtml.datastar import Signal, js

from starimo.core import ACTION_INSTALL_PACKAGE, ACTION_RUN_CELL

_MODULE_NOT_FOUND_RE = re.compile(r"No module named ['\"]([a-zA-Z0-9_.]+)['\"]")
_MARIMO_TABLE_RE = re.compile(r"<marimo-table\b[^>]*>", re.DOTALL)
_DATA_ATTR_RE = re.compile(r"data-data='([^']*)'")
_FIELD_TYPES_RE = re.compile(r"data-field-types='([^']*)'")
_TOTAL_ROWS_RE = re.compile(r"data-total-rows='(\d+)'")
_MARIMO_COMPONENT_RE = re.compile(r"<(marimo-[\w-]+)\b([^>]*)(?:/>|>)", re.DOTALL)
_MARIMO_ATTR_RE = re.compile(r"data-([\w-]+)='([^']*)'")
_MARIMO_TEX_OPEN_RE = re.compile(r"<marimo-tex\b[^>]*>")
_MARIMO_PRE_RE = re.compile(r"<pre class='text-xs'>(.*?)</pre>$", re.DOTALL)

_TAB_INDENT = js(
    "if(evt.key==='Tab'){evt.preventDefault();"
    "const s=el.selectionStart,e=el.selectionEnd;"
    "el.value=el.value.substring(0,s)+'    '+el.value.substring(e);"
    "el.selectionStart=el.selectionEnd=s+4}"
)


def extract_missing_module(error_msg: str) -> str | None:
    match = _MODULE_NOT_FOUND_RE.search(error_msg)
    return match.group(1).split(".")[0] if match else None


def module_to_pypi_name(module_name: str) -> str:
    try:
        from marimo._runtime.packages.module_name_to_pypi_name import module_name_to_pypi_name
        return module_name_to_pypi_name().get(module_name, module_name)
    except ImportError:
        return module_name


class DefaultRenderer:
    pre_code_class = "bg-gray-100 p-2 rounded text-sm overflow-x-auto"
    pre_error_class = "text-red-600 bg-red-50 p-2 rounded text-sm overflow-x-auto"
    error_container_class = "text-red-600 bg-red-50 p-3 rounded text-sm"
    error_type_class = "text-red-700"
    error_item_class = "mb-2 last:mb-0"
    install_button_class = "mt-2 px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
    install_status_class = "mt-2 text-sm text-gray-600"
    table_class = "data-table"
    table_footer_class = "text-xs text-gray-500 mt-1"
    stat_class = "stat-card"
    stat_value_class = "stat-value"
    stat_label_class = "stat-label"
    stat_caption_class = "stat-caption"
    callout_class = "callout"
    progress_container_class = "progress-container"
    progress_bar_class = "progress-bar"
    json_output_class = "json-output"
    image_class = "max-w-full h-auto"
    unsupported_class = "unsupported-component"

    # Cell chrome — only used when render_editable_cell is not overridden
    cell_container_class = "border rounded-lg overflow-hidden bg-white"
    toolbar_class = "flex items-center justify-between p-2 bg-gray-100 border-b"
    code_input_class = (
        "w-full h-32 font-mono text-sm p-3 border-0 resize-none focus:outline-none bg-gray-50"
    )
    output_container_class = "p-3 min-h-8 empty:hidden"
    run_button_class = "px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
    status_class = "text-sm text-gray-500 ml-2"

    def reset_cell_counter(self) -> None:
        pass

    def render_cell_wrapper(self, cell_id: str, children: list[Any]) -> Any:
        return Div(*children, id=f"cell-{cell_id}", cls=self.cell_container_class)

    def render_code_input(self, cell_id: str, initial_code: str) -> Any:
        code_signal = Signal(f"{cell_id}_code", initial_code)
        return (
            code_signal,
            Div(
                Textarea(
                    initial_code,
                    data_bind=code_signal,
                    data_on_input=Signal("ui_save_state").set("unsaved"),
                    data_on_keydown=_TAB_INDENT,
                    placeholder="Enter code...",
                    cls=self.code_input_class,
                ),
                cls="border-b",
            ),
        )

    def render_output_container(self, cell_id: str) -> Any:
        return Div(id=f"output-{cell_id}", cls=self.output_container_class)

    def render_status(self, cell_id: str) -> Any:
        return Span(data_text=Signal(f"{cell_id}_status", ""), cls=self.status_class)

    def render_toolbar(self, cell_id: str) -> Any:
        return Div(
            Span("Cell", cls="text-xs text-gray-500 font-medium"),
            Div(
                Button(
                    "Run",
                    data_on_click=f"@starimo('{ACTION_RUN_CELL}', '{cell_id}')",
                    cls=self.run_button_class,
                ),
                self.render_status(cell_id),
                cls="flex items-center gap-2",
            ),
            cls=self.toolbar_class,
        )

    def render_editable_cell(
        self,
        cell_id: str,
        initial_code: str = "",
        hide_code: bool = False,
        *,
        is_markdown: bool = False,
        autofocus: bool = False,
        total_cells: int | None = None,
        all_cells: list[tuple[str, int]] | None = None,
        note: str | None = None,
        output_target: str | None = None,
    ) -> Any:
        _ = hide_code, is_markdown, autofocus, total_cells, all_cells, note, output_target
        code_signal, code_div = self.render_code_input(cell_id, initial_code)

        return self.render_cell_wrapper(cell_id, [
            code_signal,
            self.render_toolbar(cell_id),
            code_div,
            self.render_output_container(cell_id),
        ])

    def render_output_content(
        self, mimetype: str, data: str | dict, channel: str | None = None, *, cell_id: str | None = None
    ) -> Any:
        if isinstance(data, dict):
            return self.render_mimebundle(data, cell_id=cell_id)
        # Normalize non-string data (error lists arrive as Python lists)
        if not isinstance(data, str):
            data = json.dumps(data) if isinstance(data, list) else str(data)

        if channel == "marimo-error" or mimetype == "application/vnd.marimo+error":
            return self._render_error_data(data, cell_id=cell_id)

        match (channel, mimetype):
            case ("stderr", _):
                return Pre(data, cls=self.pre_error_class)
            case (_, "text/markdown"):
                inner = self._unwrap_marimo_pre(data)
                content = self._replace_marimo_tex(inner if inner and inner.strip().startswith("<") else data)
                return Div(NotStr(content), cls="prose-block")
            case (_, "text/html"):
                return self._render_html(data, cell_id=cell_id)
            case (_, "text/plain"):
                return self._render_plain_text(data)
            case (_, m) if m.startswith("image/"):
                return self.render_image(f"data:{mimetype};base64,{data}")
            case (_, "application/json"):
                return self.render_json_output(data, cell_id=cell_id)
            case _:
                return Pre(data, cls=self.pre_code_class)

    def _render_error_data(self, data: str, *, cell_id: str | None = None) -> Any:
        try:
            errors = json.loads(data)
            if isinstance(errors, list):
                return self.render_error_content(errors, cell_id=cell_id)
        except (json.JSONDecodeError, TypeError):
            pass
        return Pre(data, cls=self.pre_error_class)

    def _render_html(self, data: str, *, cell_id: str | None = None) -> Any:
        data = self._replace_marimo_tex(data)
        table_data = self._extract_marimo_table(data)
        if table_data:
            return self.render_table(**table_data, cell_id=cell_id)
        component = self._dispatch_marimo_component(data, cell_id=cell_id)
        if component is not None:
            return component
        # Marimo wraps non-HTML output in <pre class='text-xs'> but labels it text/html
        unwrapped = self._unwrap_marimo_pre(data)
        if unwrapped:
            return NotStr(unwrapped) if unwrapped.strip().startswith("<") else Pre(unwrapped, cls=self.pre_code_class)
        return NotStr(data)

    def render_table(
        self,
        records: list[dict],
        columns: list[str],
        *,
        total_rows: int | None = None,
        cell_id: str | None = None,
    ) -> Any:
        if not columns and not records:
            return Span("Empty table", cls="output-placeholder")

        header = Thead(Tr(*[Th(col) for col in columns]))
        rows = [
            Tr(*[Td(str(row.get(col, ""))) for col in columns])
            for row in records
        ]
        table = Table(header, Tbody(*rows), cls=self.table_class)
        if total_rows and total_rows > len(records):
            footer = Div(f"Showing {len(records)} of {total_rows} rows", cls=self.table_footer_class)
            return Div(table, footer)
        return table

    def render_mimebundle(self, bundle: dict, *, cell_id: str | None = None) -> Any:
        metadata = bundle.get("__metadata__", {})
        for mime in ("image/svg+xml", "image/png", "image/jpeg"):
            if mime in bundle:
                src = bundle[mime]
                meta = metadata.get(mime, {})
                return self.render_image(src, width=meta.get("width"), height=meta.get("height"))
        if "text/html" in bundle:
            return NotStr(bundle["text/html"])
        if "text/plain" in bundle:
            return Pre(bundle["text/plain"], cls=self.pre_code_class)
        return Pre(str(bundle), cls=self.pre_code_class)

    def render_image(self, src: str, *, width: int | None = None, height: int | None = None) -> Any:
        attrs = {k: str(v) for k, v in {"width": width, "height": height}.items() if v}
        return Img(src=src, cls=self.image_class, **attrs)

    def render_stat(
        self, value: str, label: str = "", caption: str = "", *,
        direction: str = "increase", bordered: bool = False, cell_id: str | None = None,
    ) -> Any:
        children = []
        if label:
            children.append(Div(label, cls=self.stat_label_class))
        children.append(Div(value, cls=self.stat_value_class))
        if caption:
            children.append(Div(caption, cls=self.stat_caption_class))
        cls = self.stat_class
        if bordered:
            cls += " stat-bordered"
        return Div(*children, cls=cls, data_direction=direction)

    def render_callout(self, html_content: str, kind: str = "neutral", *, cell_id: str | None = None) -> Any:
        return Div(NotStr(html_content), cls=f"{self.callout_class} callout-{kind}")

    def render_progress(
        self, title: str = "", subtitle: str = "", total: str = "100", progress: str = "0",
        *, cell_id: str | None = None,
    ) -> Any:
        children = []
        if title:
            children.append(Div(title, cls="progress-title"))
        if progress == "true":
            children.append(Div(cls=f"{self.progress_bar_class} progress-indeterminate"))
        else:
            total_int = int(total) if total else 100
            pct = int(progress) if progress else 0
            width_pct = min(100, (pct / total_int * 100)) if total_int > 0 else 0
            children.append(
                Div(
                    Div(cls=self.progress_bar_class, style=f"width:{width_pct:.0f}%"),
                    cls=self.progress_container_class,
                )
            )
        if subtitle:
            children.append(Div(subtitle, cls="progress-subtitle"))
        return Div(*children, cls="progress-wrapper")

    def render_json_output(self, json_data: str, *, cell_id: str | None = None) -> Any:
        try:
            formatted = json.dumps(json.loads(json_data), indent=2)
        except (json.JSONDecodeError, TypeError):
            formatted = json_data
        return Pre(formatted, cls=self.json_output_class)

    def render_mermaid(self, diagram: str, *, cell_id: str | None = None) -> Any:
        return Div(diagram, data_mermaid=True)

    def render_unsupported_component(
        self, tag_name: str, raw_html: str, *, cell_id: str | None = None,
    ) -> Any:
        return Div(
            Div(Strong(f"Unsupported component: {tag_name}"), cls="unsupported-header"),
            Pre(raw_html[:500], cls=self.pre_code_class),
            cls=self.unsupported_class,
        )

    @staticmethod
    def _extract_marimo_table(data: str) -> dict[str, Any] | None:
        if not (table_match := _MARIMO_TABLE_RE.search(data)):
            return None
        tag = table_match.group(0)
        if not (data_match := _DATA_ATTR_RE.search(tag)):
            return None

        try:
            raw = html_module.unescape(data_match.group(1))
            # Double-decode: attribute value is a JSON string containing JSON
            records = json.loads(json.loads(raw))
        except (json.JSONDecodeError, TypeError):
            return None

        if not isinstance(records, list):
            return None

        columns: list[str] = []
        field_types_match = _FIELD_TYPES_RE.search(tag)
        if field_types_match:
            try:
                raw_types = html_module.unescape(field_types_match.group(1))
                field_types = json.loads(raw_types)
                columns = [ft[0] for ft in field_types]
            except (json.JSONDecodeError, TypeError, IndexError):
                pass

        if not columns and records:
            columns = list(records[0].keys())

        total_rows = int(m.group(1)) if (m := _TOTAL_ROWS_RE.search(tag)) else None

        return {"records": records, "columns": columns, "total_rows": total_rows}

    @staticmethod
    def _extract_marimo_attrs(attrs_str: str) -> dict[str, str]:
        attrs = {}
        for m in _MARIMO_ATTR_RE.finditer(attrs_str):
            val = html_module.unescape(m.group(2))
            try:
                decoded = json.loads(val)
                if isinstance(decoded, str):
                    val = decoded
            except (json.JSONDecodeError, TypeError):
                pass
            attrs[m.group(1)] = val
        return attrs

    def _dispatch_marimo_component(self, data: str, *, cell_id: str | None = None) -> Any | None:
        m = _MARIMO_COMPONENT_RE.search(data)
        if not m:
            return None
        tag_name = m.group(1)
        if tag_name == "marimo-table":
            return None  # Handled by _extract_marimo_table

        attrs = self._extract_marimo_attrs(m.group(2))

        match tag_name:
            case "marimo-stat":
                return self.render_stat(
                    value=attrs.get("value", ""),
                    label=attrs.get("label", ""),
                    caption=attrs.get("caption", ""),
                    direction=attrs.get("direction", "increase"),
                    bordered=attrs.get("bordered", "false") == "true",
                    cell_id=cell_id,
                )
            case "marimo-callout-output":
                return self.render_callout(
                    html_content=attrs.get("html", ""),
                    kind=attrs.get("kind", "neutral"),
                    cell_id=cell_id,
                )
            case "marimo-progress":
                return self.render_progress(
                    title=attrs.get("title", ""),
                    subtitle=attrs.get("subtitle", ""),
                    total=attrs.get("total", "100"),
                    progress=attrs.get("progress", "0"),
                    cell_id=cell_id,
                )
            case "marimo-json-output":
                return self.render_json_output(
                    json_data=attrs.get("json-data", "{}"),
                    cell_id=cell_id,
                )
            case "marimo-mermaid":
                return self.render_mermaid(
                    diagram=attrs.get("diagram", ""),
                    cell_id=cell_id,
                )
            case _:
                return self.render_unsupported_component(tag_name, data, cell_id=cell_id)

    @staticmethod
    def _replace_marimo_tex(data: str) -> str:
        """Convert <marimo-tex> + arithmatex delimiters to <span data-katex>."""
        if "<marimo-tex" not in data:
            return data
        data = data.replace("||(", "\\(").replace("||)", "\\)")
        data = data.replace("||[", "\\[").replace("||]", "\\]")
        data = _MARIMO_TEX_OPEN_RE.sub("<span data-katex>", data)
        data = data.replace("</marimo-tex>", "</span>")
        return data

    def render_error_content(self, errors: list[dict], *, cell_id: str | None = None) -> Any:
        elements = []
        for err in errors:
            if not isinstance(err, dict):
                elements.append(Div(str(err), cls=self.error_item_class))
                continue

            err_type = err.get("type", "unknown")
            match err_type:
                case "multiple-defs":
                    name = err.get("name", "?")
                    cells = err.get("cells", [])
                    msg = f"Variable '{name}' defined in multiple cells: {', '.join(cells[:3])}"
                    if len(cells) > 3:
                        msg += f" (+{len(cells) - 3} more)"
                case "cycle":
                    edges = err.get("edges", [])
                    msg = f"Circular dependency: {' → '.join(str(e) for e in edges[:5])}"
                case "exception" | "syntax":
                    msg = err.get("msg", f"{err_type.title()} error")
                    missing_module = extract_missing_module(msg) if err_type == "exception" else None
                    if missing_module and cell_id:
                        pypi_name = module_to_pypi_name(missing_module)
                        elements.append(self._render_install_error(err_type, msg, pypi_name, cell_id))
                        continue
                case "ancestor-stopped" | "ancestor-prevented":
                    msg = err.get("msg", "Cell blocked due to upstream error")
                case _:
                    msg = err.get("msg", str(err))

            elements.append(
                Div(
                    Strong(err_type.replace("-", " ").title(), cls=self.error_type_class),
                    Div(msg, cls="mt-1"),
                    cls=self.error_item_class,
                )
            )

        return Div(*elements, cls=self.error_container_class)

    def _render_install_error(self, err_type: str, msg: str, pypi_name: str, cell_id: str) -> Any:
        return Div(
            Strong(err_type.replace("-", " ").title(), cls=self.error_type_class),
            Div(msg, cls="mt-1"),
            Button(f"Install {pypi_name}",
                   data_on_click=f"@starimo('{ACTION_INSTALL_PACKAGE}', '{cell_id}', '{pypi_name}')",
                   cls=self.install_button_class, id=f"install-btn-{cell_id}"),
            Span("", id=f"install-status-{cell_id}", cls=self.install_status_class),
            cls=self.error_item_class,
        )

    def _render_plain_text(self, data: str) -> Any:
        unwrapped = self._unwrap_marimo_pre(data)
        if unwrapped is not None:
            data = unwrapped

        stripped = data.strip()

        # Unquote Python repr'd strings: 'content' or "content"
        if len(stripped) >= 2 and stripped[0] in ("'", '"') and stripped[-1] == stripped[0]:
            stripped = stripped[1:-1].replace("\\n", "\n").replace("\\'", "'").replace('\\"', '"')

        if stripped.startswith("<") and ">" in stripped:
            return NotStr(stripped)
        return Pre(stripped, cls=self.pre_code_class)

    @staticmethod
    def _unwrap_marimo_pre(data: str) -> str | None:
        """Strip marimo's ``<pre class='text-xs'>`` wrapper, or return None."""
        if not data:
            return None
        match = _MARIMO_PRE_RE.match(data.strip())
        if not match:
            return None
        return html_module.unescape(match.group(1)).strip()


__all__ = ["DefaultRenderer", "extract_missing_module", "module_to_pypi_name"]
