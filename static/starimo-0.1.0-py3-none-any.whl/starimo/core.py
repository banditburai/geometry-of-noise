import ast
import json
import keyword
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Callable

from fastcore.xml import FT, NotStr, to_xml
from marimo._runtime.state import State as _MarimoState
from starhtml.datastar import Expr as _Expr


def _register_ft_formatter() -> None:
    from marimo._output.formatting import FORMATTERS
    # str() converts Safe → plain str for msgspec serialization
    FORMATTERS.add_formatter(FT, lambda ft: ("text/html", str(to_xml(ft, indent=False))))

logger = logging.getLogger(__name__)

STARIMO_PREAMBLE_NAME = "_starimo_ui_preamble"
STARIMO_SIGNAL_SYNC_NAME = "_starimo_signal_sync"
STARIMO_SEED_NAME = "_starimo_seed"

STARIMO_UI_PREAMBLE_CODE = '''# Starimo UI Preamble
from starimo.core import _register_ft_formatter as _reg_ft; _reg_ft()

import starhtml.tags as h
from starhtml.datastar import js, f_, seq, evt, el, Math, JSON, console
from starimo.core import get_or_create_signal as Signal

# Export for dependency tracking
h, Signal, js, f_, seq, evt, el, Math, JSON, console
'''

STARIMO_SEED_BOOTSTRAP_CODE = '''import marimo as mo
starimo_values = {}
mo
'''

CELLS_CONTAINER_ID = "starimo-cells"

ACTION_RUN_CELL = "runCell"
ACTION_ADD_CELL = "addCell"
ACTION_RUN_ALL = "runAll"
ACTION_SAVE = "save"
ACTION_DELETE_CELL = "deleteCell"
ACTION_CLEAR_OUTPUT = "clearOutput"
ACTION_INSTALL_PACKAGE = "installPackage"


@dataclass
class CellInfo:
    id: str
    code: str
    name: str = ""
    hide_code: bool = False
    is_markdown: bool = False
    status: str = "idle"
    output: Any = None
    error: str | None = None
    execution_time: float | None = None
    defs: set[str] = field(default_factory=set)
    output_target: str | None = field(default=None, repr=False)
    note: str | None = field(default=None, repr=False)


def find_seed_cell(cells: dict[str, CellInfo]) -> CellInfo | None:
    return next((c for c in cells.values() if "starimo_values" in c.defs), None)


def _eval_literal(node: ast.expr) -> Any:
    match node:
        case ast.Constant():
            return node.value
        case ast.List():
            return [_eval_literal(el) for el in node.elts]
        case ast.Dict():
            return {_eval_literal(k): _eval_literal(v) for k, v in zip(node.keys, node.values) if k is not None}
        case ast.Tuple():
            return tuple(_eval_literal(el) for el in node.elts)
        case _:
            return None


def _find_starimo_values_node(code: str) -> ast.Assign | None:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None
    for node in ast.walk(tree):
        if (isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == "starimo_values"):
            return node
    return None


def extract_starimo_values(code: str) -> dict[str, Any]:
    """Extract initial signal values from `starimo_values = {...}` assignment."""
    node = _find_starimo_values_node(code)
    if node and isinstance(node.value, ast.Dict):
        return _eval_literal(node.value)
    return {}


def parse_variable_value(value: Any) -> Any:
    """Decode marimo's variable format (JSON-encoded strings, "None" literal)."""
    if not isinstance(value, str):
        return value
    if value == "None":
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


@dataclass
class SignalRegistry:
    """Tracks signal values and pending changes for sync batching."""

    _values: dict[str, Any] = field(default_factory=dict)
    _pending: dict[str, Any] = field(default_factory=dict)

    def get(self, name: str, default: Any = None) -> Any:
        return self._values.get(name, default)

    def get_all(self) -> dict[str, Any]:
        return self._values.copy()

    def has_pending_changes(self) -> bool:
        return bool(self._pending)

    def clear_pending_changes(self) -> None:
        self._pending.clear()

    def update(self, name: str, value: Any) -> bool:
        if self._values.get(name) == value:
            return False
        self._values[name] = value
        self._pending[name] = value
        return True

    def set_without_pending(self, name: str, value: Any) -> bool:
        """Avoids sync loop — accepts value from kernel without marking pending."""
        if self._values.get(name) == value:
            return False
        self._values[name] = value
        return True


class SeedCellGuardError(RuntimeError):
    pass


class SeedCellGuard:
    def __init__(self, seed_name: str):
        self.seed_name = seed_name
        logger.debug(f"[seed_guard] Initialized for: {seed_name}")

    def check_cell(self, cell_name: str, operation: str = "run") -> None:
        if cell_name == self.seed_name:
            raise SeedCellGuardError(
                f"Cannot {operation} seed cell '{self.seed_name}': "
                f"re-running would orphan existing mo.state and break signal sync. "
                f"Use bridge.set_input() to update values, or restart kernel."
            )

    def filter_cells(self, cell_names: list[str]) -> list[str]:
        return [n for n in cell_names if n != self.seed_name]

    def is_seed_cell(self, cell_name: str) -> bool:
        return cell_name == self.seed_name


_setters: dict[str, Callable[[Any], None]] = {}


def register_setter(name: str, setter: Callable[[Any], None]) -> None:
    _setters[name] = setter


def call_setter(name: str, value: Any) -> bool:
    if name in _setters:
        _setters[name](value)
        return True
    return False


def reset_signal_state() -> None:
    """Test-only."""
    _setters.clear()
    _signal_instances.clear()


_MISSING = object()


class ReactiveSignal(_MarimoState, _Expr):
    """Signal with mo.state backing for bidirectional Python↔Datastar binding.

    Usage:
        sig = Signal("count", 0)
        sig()           # get current Python value
        sig(42)         # set value from Python (triggers mo.state reactivity)
        sig.set(42)     # JS expression: $count = 42
        sig >= 0        # JS expression: ($count >= 0)
    """

    def __init__(self, name: str, initial: Any = None, debounce: int | None = None):
        _MarimoState.__init__(self, initial)
        self._name = name
        self._initial = initial
        self._js = f"${name}"
        self._id = name
        self._debounce = debounce
        self._initial_changed = False
        self._value_changed = False
        register_setter(name, self._set_value)

    def to_js(self) -> str:
        return self._js

    def __call__(self, value=_MISSING):
        if value is _MISSING:
            return self._value
        self._set_value(value)
        self._value_changed = True
        return self

    def __repr__(self):
        return f"ReactiveSignal({self._name!r}, value={self._value!r})"

    def __hash__(self):
        return id(self)

    def _mime_(self):
        """Context-sensitive display.

        After setter call (sig(val)) or initial change on re-run:
          → text/html with data-signals attr (pushes value to browser)
        Otherwise (e.g. signal inside a tuple, bare inspection):
          → text/plain showing the current value
        """
        if self._value_changed or self._initial_changed:
            # str() converts Safe → plain str for msgspec serialization
            return ("text/html", str(to_xml(self.__ft__())))
        return ("text/plain", repr(self._value))

    def __ft__(self):
        """Declare this Datastar signal via a minimal FT element.

        Three modes:
        1. _value_changed (Python called sig(val)): render _value, no __ifmissing
           → forces browser to show the Python-computed value + visible badge
        2. _initial_changed (get_or_create_signal saw new initial): render new initial, no __ifmissing
           → forces browser to update when cell code changes the default
        3. Normal: render _initial with __ifmissing
           → preserves user-modified browser values across re-renders

        Flags are NOT reset here — they persist across multiple __ft__() calls
        within the same cell execution. Marimo may call to_xml (→ __ft__) more
        than once per render cycle. Flags are managed by get_or_create_signal:
        cleared at the START of the next cell run when the factory is called.
        """
        if self._value_changed:
            key = f"data-signals:{self._name}"
            val = NotStr(json.dumps(self._value))
        elif self._initial_changed:
            key = f"data-signals:{self._name}"
            val = NotStr(json.dumps(self._initial))
        else:
            key = f"data-signals:{self._name}__ifmissing"
            val = NotStr(json.dumps(self._initial))
        attrs = {key: val}
        if self._debounce is not None:
            attrs[f"data-signal-debounce-{self._name}"] = NotStr(str(self._debounce))
        signal_span = FT("span", (), {**attrs, "class": "signal-output"})

        if self._value_changed:
            value_str = str(self._value)
            if len(value_str) > 60:
                value_str = value_str[:57] + "\u2026"
            return FT("div", (
                signal_span,
                FT("div", (
                    FT("span", ("\u2192 ",), {}),
                    FT("span", (self._name,), {"class": "signal-setter-name"}),
                    FT("span", (value_str,), {"class": "signal-setter-value"}),
                ), {"class": "signal-setter-badge"}),
            ), {"class": "signal-setter", "data-signal-name": self._name})

        return signal_span


_signal_instances: dict[str, ReactiveSignal] = {}


def get_or_create_signal(name: str, initial: Any = None, debounce: int | None = None) -> ReactiveSignal:
    """Args:
        debounce: Frontend sync debounce in ms. None = global default (300ms),
                  0 = immediate sync (like marimo slider with debounce=False).
    """
    if name in _signal_instances:
        existing = _signal_instances[name]
        if debounce is not None and existing._debounce != debounce:
            existing._debounce = debounce
        # Clear stale _value_changed from previous cell run.
        # If sig(value) is called in THIS run, it will set it again.
        existing._value_changed = False
        if initial is not None and existing._initial != initial:
            existing._initial = initial
            # Bypass _set_value to avoid triggering marimo state reactivity
            existing._value = initial
            existing._initial_changed = True
        elif (initial is not None
              and isinstance(initial, list)
              and isinstance(existing._value, list)
              and len(existing._value) != len(initial)):
            # Safety net: array length mismatch indicates corruption from
            # Datastar Proxy auto-vivification (reading missing indices
            # creates signal("") entries). Reset to the declared initial.
            existing._value = list(initial)
            existing._initial_changed = True
        else:
            # Initial unchanged — clear the flag (previous render
            # already pushed the new initial to the browser).
            existing._initial_changed = False
        return existing
    signal = ReactiveSignal(name, initial, debounce=debounce)
    _signal_instances[name] = signal
    return signal


def get_signal_debounce_map() -> dict[str, int]:
    return {
        name: sig._debounce
        for name, sig in _signal_instances.items()
        if sig._debounce is not None
    }


def _format_values_dict(d: dict[str, Any]) -> str:
    items = "\n".join(f"    {k!r}: {v!r}," for k, v in d.items())
    return f"starimo_values = {{\n{items}\n}}"


def update_starimo_values_code(code: str, updates: dict[str, Any]) -> str:
    """Update the starimo_values dict in seed cell code via AST line replacement."""
    existing = extract_starimo_values(code)
    existing.update(updates)
    node = _find_starimo_values_node(code)
    if node:
        lines = code.splitlines(keepends=True)
        before = lines[:node.lineno - 1]
        after = lines[node.end_lineno:]
        return "".join(before) + _format_values_dict(existing) + "\n" + "".join(after)
    return code.rstrip() + "\n" + _format_values_dict(updates) + "\n"


def is_markdown(code: str) -> bool:
    return "marimo.md(" in code or "mo.md(" in code


# Handles any string prefix combination: r""", f""", rf""", fr""", or plain """.
_MD_UNWRAP_RE = re.compile(
    r'(?:mo|marimo)\.md\(\s*(?:[rfRFbBuU]{0,2})("""(.*?)"""|"([^"]*)")\s*\)',
    re.DOTALL,
)


def unwrap_markdown(code: str) -> str | None:
    m = _MD_UNWRAP_RE.search(code)
    if not m:
        return None
    raw = m.group(2) if m.group(2) is not None else (m.group(3) or "")
    return raw.strip()


_NON_RAW_MD_RE = re.compile(
    r'((?:mo|marimo)\.md\(\s*)(?!r)(""")',
)


def ensure_raw_md_string(code: str) -> str:
    r"""Upgrade ``mo.md(\"\"\"...\"\"\"`` to ``mo.md(r\"\"\"...\"\"\")``.

    Without the ``r`` prefix, Python interprets ``\f`` as form-feed
    which breaks TeX commands like ``\frac``, ``\forall``, etc.
    """
    return _NON_RAW_MD_RE.sub(r'\1r\2', code)


_DISPLAY_MATH_RE = re.compile(r"\\\[([\s\S]*?)\\\]")


def display_math_to_dollars(md: str) -> str:
    r"""Convert ``\[...\]`` display math to ``$$...$$``.

    Marimo's markdown parser escapes ``\[`` to ``[`` before arithmatex can
    recognize it as display math.  ``$$...$$`` on its own paragraph works.
    """
    return _DISPLAY_MATH_RE.sub(r"\n$$\1$$\n", md)


_MERMAID_FENCE_RE = re.compile(r"```mermaid\s*\n([\s\S]*?)```")


def mermaid_fences_to_divs(md: str) -> str:
    """Marimo renders mermaid fences as plain code blocks. Converting to
    raw HTML divs lets StarHTML's mermaid plugin render them client-side.
    """
    return _MERMAID_FENCE_RE.sub(r"<div data-mermaid>\1</div>", md)


def parse_names(code: str) -> tuple[set[str], set[str]]:
    try:
        tree = ast.parse(code)
        defs, refs = set(), set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                if isinstance(node.ctx, ast.Store):
                    defs.add(node.id)
                elif isinstance(node.ctx, ast.Load):
                    refs.add(node.id)
        return defs, refs
    except SyntaxError:
        return set(), set()


_NON_ALNUM_RE = re.compile(r'[^a-z0-9_]+')
_LEADING_DIGITS_RE = re.compile(r'^[0-9]+')
_MULTI_UNDERSCORE_RE = re.compile(r'_+')


def normalize_cell_name(name: str) -> str:
    name = name.lower().strip()
    name = _NON_ALNUM_RE.sub('_', name)
    name = _LEADING_DIGITS_RE.sub('', name)
    name = _MULTI_UNDERSCORE_RE.sub('_', name)
    name = name.strip('_')
    return name


def validate_cell_name(name: str, existing: set[str]) -> str | None:
    if not name:
        return "Name cannot be empty"
    if not name.isidentifier():
        return "Must be a valid Python identifier"
    if keyword.iskeyword(name):
        return f"'{name}' is a Python keyword"
    # marimo treats _-prefixed names as cell-private (filtered from defs)
    if name.startswith("_"):
        return "Names starting with '_' are reserved"
    if name in existing:
        return f"'{name}' already exists"
    return None


def cleanup_cell_signals(old_cell_id: str) -> None:
    prefix = f"{old_cell_id}_"
    for n in [k for k in _signal_instances if k.startswith(prefix)]:
        del _signal_instances[n]
        _setters.pop(n, None)


__all__ = [
    "STARIMO_PREAMBLE_NAME",
    "STARIMO_SIGNAL_SYNC_NAME",
    "STARIMO_SEED_NAME",
    "STARIMO_UI_PREAMBLE_CODE",
    "STARIMO_SEED_BOOTSTRAP_CODE",
    "CELLS_CONTAINER_ID",
    "ACTION_RUN_CELL",
    "ACTION_ADD_CELL",
    "ACTION_RUN_ALL",
    "ACTION_SAVE",
    "ACTION_DELETE_CELL",
    "ACTION_CLEAR_OUTPUT",
    "ACTION_INSTALL_PACKAGE",
    "CellInfo",
    "find_seed_cell",
    "extract_starimo_values",
    "parse_variable_value",
    "SignalRegistry",
    "SeedCellGuard",
    "SeedCellGuardError",
    "call_setter",
    "ReactiveSignal",
    "get_or_create_signal",
    "get_signal_debounce_map",
    "update_starimo_values_code",
    "is_markdown",
    "unwrap_markdown",
    "ensure_raw_md_string",
    "display_math_to_dollars",
    "mermaid_fences_to_divs",
    "parse_names",
    "normalize_cell_name",
    "validate_cell_name",
    "cleanup_cell_signals",
    "reset_signal_state",
]
