"""Starimo plugin for StarHTML - Connects Datastar frontends to Marimo backends."""

import ast
import hashlib
import inspect
import logging
from pathlib import Path
from types import ModuleType
from typing import Any

import httpx

from starhtml import Span
from starhtml.datastar import js, scroll_to, Signal
from starhtml.plugins import PluginInstance
from starimo.core import (
    ACTION_ADD_CELL,
    ACTION_CLEAR_OUTPUT,
    ACTION_RUN_ALL,
    ACTION_RUN_CELL,
    ACTION_SAVE,
    STARIMO_SEED_NAME,
)
from starimo.wasm import is_pyodide

logger = logging.getLogger(__name__)

_STATIC_PATH = Path(__file__).parent / "static" / "js" / "plugins"
_PACKAGE_NAME = "starimo/plugins"

DEFAULT_SPAWNER_HOST = "localhost"
DEFAULT_SPAWNER_PORT = 2718


def _default_renderer():
    from starimo.renderer import DefaultRenderer
    return DefaultRenderer()

# Module-level imports that appear as cell defs but aren't data outputs
IMPORT_ALIASES = frozenset({
    "np", "numpy", "pd", "pandas", "plt", "matplotlib", "mo", "marimo",
})

MARIMO_SETUP_CELL_NAME = "setup"


def _is_import_only_cell(code: str) -> bool:
    try:
        tree = ast.parse(code)
        return all(isinstance(node, (ast.Import, ast.ImportFrom, ast.Expr)) for node in tree.body)
    except SyntaxError:
        return False


def discover_notebook(notebook_path: Path) -> tuple[list[str], dict[str, Any]]:
    """Parse notebook once to extract both output names and seed cell values."""
    if not notebook_path.exists():
        return [], {}

    try:
        from marimo._ast.load import load_app
        from starimo.core import extract_starimo_values

        app = load_app(notebook_path)
        if app is None:
            return [], {}
        cm = app._cell_manager
        all_defs: set[str] = set()
        values: dict[str, Any] = {}

        for cell_id in cm.cell_ids():
            cell_data = cm.cell_data_at(cell_id)
            if cell_data.name == STARIMO_SEED_NAME:
                values = extract_starimo_values(cell_data.code)
                continue
            if cell_data.name and cell_data.name.startswith("_starimo_"):
                continue
            if cell_data.name == MARIMO_SETUP_CELL_NAME:
                continue
            if _is_import_only_cell(cell_data.code):
                continue
            if cell_data.cell:
                all_defs.update(cell_data.cell.defs)

        outputs = [
            name for name in sorted(all_defs)
            if not name.startswith("_") and name not in IMPORT_ALIASES
        ]
        return outputs, values

    except Exception as e:
        logger.warning(f"[starimo] Could not parse notebook {notebook_path}: {e}")
        return [], {}


def _get_caller_info() -> tuple[Path, str]:
    """Walk the stack to find the file that created the plugin (outside this package)."""
    this_package_dir = Path(__file__).parent

    for frame_info in inspect.stack():
        frame_file = frame_info.filename
        if frame_file.startswith("<"):
            continue
        frame_path = Path(frame_file)
        if frame_path.is_relative_to(this_package_dir):
            continue
        return frame_path.parent, frame_path.stem

    return Path.cwd(), "notebook"


class StarimoPlugin(PluginInstance):
    """StarHTML plugin for Marimo integration via spawner daemon or WASM."""

    def __init__(
        self,
        notebook: str | Path | None = None,
        dependencies: list[str] | None = None,
        editable_sources: dict[str, str] | None = None,
        spawner_host: str = DEFAULT_SPAWNER_HOST,
        spawner_port: int = DEFAULT_SPAWNER_PORT,
        auto_run: bool = True,
        mode: str | None = None,
        renderer: Any = None,
        theme: str | ModuleType | None = None,
    ):
        self._mode = mode
        self._renderer = renderer
        self._theme = self._resolve_theme(theme)
        self.dependencies = dependencies or []
        self.editable_sources = editable_sources or {}
        self.spawner_host = spawner_host
        self.spawner_port = spawner_port
        self.auto_run = auto_run
        self._caller_dir, self._caller_stem = _get_caller_info()

        if notebook:
            notebook_path = Path(notebook)
            self.notebook_path = notebook_path if notebook_path.is_absolute() else self._caller_dir / notebook_path
        else:
            self.notebook_path = None

        self._discovered_outputs: list[str] = []
        self._starimo_values: dict[str, Any] = {}
        if self.notebook_path:
            self._discovered_outputs, self._starimo_values = discover_notebook(self.notebook_path)
            logger.debug(f"[starimo] Discovered outputs: {self._discovered_outputs}")
            logger.debug(f"[starimo] Starimo values: {self._starimo_values}")

        theme_css = getattr(self._theme, "CRITICAL_CSS", None) if self._theme else None

        super().__init__(
            name="starimo",
            base_name="starimo",
            code=None,
            signals=("mo_status", "mo_ready", "error"),
            methods=(),
            config={"signal": "starimo"},
            static_path=_STATIC_PATH,
            package_name=_PACKAGE_NAME,
            critical_css=theme_css,
        )

        # Widen from dict[str, Signal] to accept JsRaw (both are Expr subclasses)
        self._refs: dict[str, Any] = self._refs
        self._refs["run_all"] = js(f"@starimo('{ACTION_RUN_ALL}')")
        self._refs["run_cell"] = js(f"@starimo('{ACTION_RUN_CELL}')")
        self._refs["add_cell"] = js(f"@starimo('{ACTION_ADD_CELL}')")
        self._refs["clear_output"] = js(f"@starimo('{ACTION_CLEAR_OUTPUT}')")
        self._refs["save"] = js(f"@starimo('{ACTION_SAVE}')")

        # Notebook metadata — always available, even for fresh notebooks
        self._refs["notebook_title"] = Signal(
            "notebook_title", self._starimo_values.get("notebook_title", ""),
        )
        self._refs["notebook_description"] = Signal(
            "notebook_description", self._starimo_values.get("notebook_description", ""),
        )

        for name in self._discovered_outputs:
            try:
                self._refs[name] = Signal(name, self._starimo_values.get(name))
            except ValueError:
                logger.debug(f"[starimo] Skipping output '{name}' (not a valid signal name)")

        for datastar_name, value in self._starimo_values.items():
            if datastar_name.startswith("_"):
                continue
            if datastar_name not in self._refs:
                self._refs[datastar_name] = Signal(datastar_name, value)

        self._refs["mo_status"] = Signal("starimo_status", "disconnected")
        self._refs["mo_ready"] = Signal("starimo_ready", False)
        self._refs["error"] = Signal("starimo_error", "")

        self._bridge: Any = None
        self._marimo_port: int | None = None

    @staticmethod
    def _resolve_theme(theme: str | ModuleType | None) -> ModuleType | None:
        if theme is None:
            return None
        if isinstance(theme, ModuleType):
            return theme
        from starimo.ui.themes import get_theme
        return get_theme(theme)

    @property
    def file_actions(self) -> bool:
        return True

    @property
    def notebook_id(self) -> str:
        path_hash = hashlib.sha256(str(self._caller_dir).encode()).hexdigest()[:8]
        return f"{self._caller_stem}-{path_hash}"

    @property
    def notebook_hash(self) -> str:
        """Short hash of notebook path for client-side scoping (folds, persist)."""
        if self.notebook_path:
            return hashlib.sha256(str(self.notebook_path).encode()).hexdigest()[:12]
        return ""

    @property
    def effective_mode(self) -> str:
        if self._mode is not None:
            return self._mode
        return "wasm" if is_pyodide() else "spawner"

    @property
    def wasm_mode(self) -> bool:
        return self.effective_mode == "wasm"

    @property
    def spawner_url(self) -> str:
        return f"http://{self.spawner_host}:{self.spawner_port}"

    @property
    def marimo_url(self) -> str:
        if self._marimo_port is None:
            raise RuntimeError("Marimo not spawned yet")
        return f"ws://127.0.0.1:{self._marimo_port}/ws"

    @property
    def marimo_http_url(self) -> str:
        if self._marimo_port is None:
            raise RuntimeError("Marimo not spawned yet")
        return f"http://127.0.0.1:{self._marimo_port}"

    async def _spawn_notebook(self) -> int:
        if not self.notebook_path:
            raise ValueError("notebook parameter is required")
        if not self.notebook_path.exists():
            raise FileNotFoundError(f"Notebook file not found: {self.notebook_path}")

        logger.info(f"[starimo] Requesting spawn for {self.notebook_id} at {self.notebook_path}")

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.spawner_url}/spawn",
                    json={"notebook_id": self.notebook_id, "notebook_path": str(self.notebook_path)},
                    timeout=60.0,
                )
                if response.status_code != 200:
                    raise RuntimeError(f"Spawner error: {response.text}")

                result = response.json()
                port = result["port"]
                logger.info(f"[starimo] Spawned {self.notebook_id} on port {port} ({result['status']})")
                return port

            except httpx.ConnectError:
                raise RuntimeError(
                    f"Could not connect to starimo spawner at {self.spawner_url}. "
                    "Start with 'starimo serve <app.py>' or 'starimo daemon'."
                )

    async def on_startup(self, app: "Starlette") -> None:
        import os
        if os.environ.get("STARDUST_BUILD"):
            # Build-time pre-render path: stardust is running the app in host
            # Python to render `/` into static HTML. The WASM bridge /
            # spawner paths need Pyodide / a live event loop and MUST NOT run
            # here. Signal registrations already happened in __init__, so the
            # rendered HTML will contain all `data-signals:*` attributes.
            logger.info("[starimo] STARDUST_BUILD=1 — skipping on_startup for build-time pre-render.")
            return

        from starhtml.realtime import Relay
        from starimo.routes import create_starimo_router

        mode = self.effective_mode
        logger.info(f"[starimo] Using {mode} mode (auto-detected: {self._mode is None})")

        # Resolve renderer: explicit > theme > default (None)
        resolved_renderer = self._renderer
        if resolved_renderer is None and self._theme is not None:
            resolved_renderer = getattr(self._theme, "RENDERER", None)
        self._resolved_renderer = resolved_renderer

        relay = Relay()
        app.state.starimo_relay = relay

        def _on_signals(updates: dict[str, Any]) -> None:
            logger.debug(f"[starimo] Signal update: {len(updates)} changes")
            relay.emit_signals(updates)

        def _on_cell_output(cell_id: str, output: dict) -> None:
            renderer = self._resolved_renderer or _default_renderer()
            data = output.get("data", "")
            mimetype = output.get("mimetype", "text/plain")
            channel = output.get("channel")
            if isinstance(data, dict):
                text = data.get("text") or data.get("html") or data.get("content")
                if text:
                    data = text
            content = renderer.render_output_content(mimetype, data, channel, cell_id=cell_id)
            logger.debug(f"[starimo] Cell output: {cell_id} ({mimetype})")

            cell = self._bridge.get_cell(cell_id) if self._bridge else None
            target = cell.output_target if cell else None
            if target:
                cells = self._bridge.cells if self._bridge else {}
                user_cells = [(n, c) for n, c in cells.items() if not n.startswith("_starimo_")]
                num_map = {n: i + 1 for i, (n, _) in enumerate(user_cells)}
                cell_num = num_map.get(cell_id)
                label = f"\u2190 from {cell_id}" + (f" ({cell_num:02d})" if cell_num else "")
                ui_active = Signal("ui_active_cell", "")
                attr = Span(label, cls="output-annex-attribution", data_on_click=[scroll_to(f"#cell-{cell_id}"), ui_active.set(cell_id)])
                relay.emit_element(attr, f"#output-annex-{target}", mode="inner")
                relay.emit_element(content, f"#output-annex-{target}", mode="append")
                relay.emit_element("", f"#output-content-{cell_id}", mode="inner")
            else:
                relay.emit_element(content, f"#output-content-{cell_id}", mode="inner")

        def _on_cell_status(cell_id: str, status: str, execution_time: float | None) -> None:
            relay.emit_signals({
                f"{cell_id}_status": "" if status == "idle" else status,
                f"{cell_id}_time": f"{execution_time:.2f}s" if execution_time else "",
            })

        def _on_ready() -> None:
            logger.debug("[starimo] on_ready callback fired")
            relay.emit_signals({"starimo_ready": True, "starimo_status": "connected"})

        def _on_cell_code_change(cell_id: str, code: str) -> None:
            import json
            logger.debug(f"[starimo] Code changed for {cell_id} ({len(code)} chars)")
            relay.emit_script(
                f"document.getElementById('code-{cell_id}')?.setAttribute('value', {json.dumps(code)})"
            )

        def _on_cell_deleted(cell_id: str) -> None:
            logger.debug(f"[starimo] Cell deleted: {cell_id}")
            relay.emit_element("", f"#cell-{cell_id}", mode="remove")

        if self.wasm_mode:
            from starimo.wasm import WasmBridge

            if not self.notebook_path:
                raise ValueError("notebook parameter is required for WASM mode")

            self._bridge = WasmBridge(
                notebook_path=str(self.notebook_path),
                signal_callback=_on_signals,
            )
            self._bridge.on_cell_output = _on_cell_output

            try:
                await self._bridge.initialize()
                if self.auto_run:
                    await self._bridge._ensure_seed_cell()
                    await self._bridge.initialize_seed_cell()
                    await self._bridge.run_all_cells()
            except Exception as e:
                logger.error(f"[starimo] Failed to initialize WASM bridge: {e}")

        else:
            from starimo.bridge import MarimoBridge

            try:
                self._marimo_port = await self._spawn_notebook()
                self._bridge = MarimoBridge(
                    marimo_url=self.marimo_url,
                    marimo_http_url=self.marimo_http_url,
                    notebook_path=self.notebook_path,
                )
                self._bridge.on_variables_batch = _on_signals
                self._bridge.on_cell_output = _on_cell_output
                self._bridge.on_cell_status = _on_cell_status
                self._bridge.on_cell_code_change = _on_cell_code_change
                self._bridge.on_cell_deleted = _on_cell_deleted
                self._bridge.on_ready = _on_ready

                await self._bridge.connect()
                await self._bridge.wait_ready()

                if self.auto_run and not self._bridge.resumed:
                    logger.info("[starimo] Fresh start: initializing seed cell, then running all cells")
                    await self._bridge._ensure_seed_cell()
                    await self._bridge.initialize_seed_cell()
                    await self._bridge._ensure_ui_preamble()
                    await self._bridge.run_all_cells()
                elif self._bridge.resumed:
                    logger.info("[starimo] Skipping cell execution (marimo resumed with existing state)")
            except Exception as e:
                logger.error(f"[starimo] Failed to spawn/connect: {e}")

        app.state.starimo_bridge = self._bridge

        from starimo.core import get_signal_debounce_map
        initial_values = {k: v for k, v in self._starimo_values.items() if not k.startswith("_")}
        initial_values.setdefault("notebook_title", "")
        initial_values.setdefault("notebook_description", "")
        router = create_starimo_router(
            initial_values=initial_values,
            debounce_map=get_signal_debounce_map(),
            renderer=resolved_renderer or _default_renderer(),
        )
        router.to_app(app)
        logger.info(f"[starimo] Initialized ({self.notebook_id}, mode={mode})")

    async def on_shutdown(self, _app: "Starlette") -> None:
        if self._bridge:
            await self._bridge.disconnect()


__all__ = ["StarimoPlugin"]
