"""Rationalist Notebook v1 - StarHTML components."""

import re

from starhtml import (
    Button, Div, Header, Input, Icon, Option, Pre, Select, Span,
)
from starhtml.datastar import Signal, el, js, scroll_to, set_timeout
from starimo.core import CELLS_CONTAINER_ID, ACTION_DELETE_CELL
from starimo.ui.editor import CodeEditor

ui_save_state = Signal("ui_save_state", "saved")

_OVERFLOW_THRESHOLD = 20  # lines; aligns with .code-editor-wrap[data-overflows] max-height



def NotebookLayout(*children, cls="", sticky_strip=True, **kwargs):
    """Main notebook container with centered layout and optional sticky strip."""
    from starhtml.datastar import Signal

    all_children = [
        (hide_all_code := Signal("hide_all_code", False)),
        Signal("ui_active_cell", ""),
        (ui_expanded := Signal("ui_expanded", {})),
        *children,
    ]
    if sticky_strip:
        all_children.append(StickySettingsStrip())

    return Div(
        *all_children,
        cls=f"notebook {cls}".strip(),
        data_persist=[hide_all_code, ui_expanded],
        data_class_hide_all_code=hide_all_code,
        # Guard: if target is detached (e.g. CM6 fold recreated DOM), don't deselect
        data_on_click="(evt.target.isConnected && !evt.target.closest('.cell')) && ($ui_active_cell = '')",
        data_on_keydown=("evt.key === 'Escape' && ($ui_active_cell = '')", dict(window=True)),
        **kwargs,
    )


def CellsContainer(cls=""):
    """Container where cells are appended via SSE."""
    return Div(id=CELLS_CONTAINER_ID, cls=cls)



def NotebookHeader(title_signal=None, desc_signal=None, editable=True, show_settings=True, cls=""):
    """Newspaper-style header with editable title, description, and settings strip."""
    from starhtml.datastar import Signal

    if editable:
        title_el = EditableTitle(signal=title_signal)
        desc_el = EditableDescription(signal=desc_signal)
    else:
        title_sig = title_signal or Signal("notebook_title", "")
        desc_sig = desc_signal or Signal("notebook_description", "")
        title_el = Div(cls="nb-title", data_text=title_sig)
        desc_el = Div(cls="nb-meta", data_text=desc_sig)

    title_row = Div(title_el, desc_el, cls="nb-header-title-row")

    children = [title_row]
    if show_settings:
        children.append(SettingsStrip())

    return Header(*children, cls=f"nb-header {cls}".strip())


def EditableTitle(signal=None, placeholder="Untitled"):
    from starhtml.datastar import Signal

    sig = signal if signal is not None else Signal("notebook_title", "")
    return Input(
        type="text",
        value=sig._initial or "",
        data_bind=sig,
        placeholder=placeholder,
        cls="nb-title nb-title-editable",
        data_on_keydown="evt.key === 'Enter' && evt.target.blur()",
    )


def EditableDescription(signal=None, placeholder="Add a description..."):
    from starhtml.datastar import Signal

    sig = signal if signal is not None else Signal("notebook_description", "")
    return Input(
        type="text",
        value=sig._initial or "",
        data_bind=sig,
        placeholder=placeholder,
        cls="nb-desc-editable",
    )



def SettingsPill(label, signal_name, default=True):
    from starhtml.datastar import Signal

    return Div(
        (sig := Signal(signal_name, default)),
        Span(cls="settings-pill-dot"),
        Span(label, cls="settings-pill-label"),
        cls="settings-pill",
        data_on_click=sig.toggle(),
        data_class_on=sig,
        role="switch",
        aria_label=f"Toggle {label}",
    )


def ActionPill(label, action, icon=None):
    children = []
    if icon:
        children.append(Icon(icon, cls="settings-pill-icon"))
    children.append(Span(label, cls="settings-pill-label"))

    return Button(
        *children,
        cls="settings-pill settings-pill--action",
        data_on_click=f"@starimo('{action}')",
        aria_label=label,
    )


def SaveIndicator():
    from starhtml.datastar import match

    return Div(
        ui_save_state,
        Div(
            cls="save-indicator-dot",
            data_attr_cls=match(ui_save_state, saved="saved", unsaved="unsaved", saving="saving"),
        ),
        Span("Saved", data_show=(ui_save_state == "saved")),
        Span("Save", data_show=(ui_save_state == "unsaved")),
        Span("Saving...", data_show=(ui_save_state == "saving")),
        cls="save-indicator",
        data_on_click=(ui_save_state == "unsaved").then("@starimo('save')"),
        data_class_clickable=(ui_save_state == "unsaved"),
        role="button",
        aria_label="Save notebook",
    )


def StripSeparator():
    return Span(cls="settings-strip-sep")


def ThemeToggle():
    """Icon switching handled in CSS (styles.css)."""
    from starhtml.datastar import js

    return Button(
        Span(Icon("lucide:sun"), cls="theme-icon-light"),
        Span(Icon("lucide:moon"), cls="theme-icon-dark"),
        data_on_click=js(
            "const cur = document.documentElement.getAttribute('data-theme');"
            "const next = cur === 'dark' ? 'light' : 'dark';"
            "document.documentElement.setAttribute('data-theme', next);"
            "localStorage.setItem('theme', next);"
        ),
        cls="settings-pill settings-pill--action settings-pill--square",
        aria_label="Toggle dark mode",
    )


def _default_strip_children():
    return [
        SettingsPill("Auto-run", "auto_run_stale", default=True),
        SettingsPill("Hide Code", "hide_all_code", default=False),
        StripSeparator(),
        ActionPill("Run All", "runAll", icon="lucide:play"),
        ActionPill("Run Stale", "runStale", icon="lucide:refresh-cw"),
        ThemeToggle(),
    ]


def SettingsStrip(*children, cls="", show_save=True):
    children = list(children) if children else _default_strip_children()
    if show_save:
        children.append(SaveIndicator())
    return Div(*children, cls=f"settings-strip {cls}".strip())


def StickySettingsStrip(show_save=True, header_height=150):
    """Appears on scroll-up past the header."""
    from starhtml.datastar import Signal
    from starhtml.plugins import scroll

    # ui_ prefix excludes from sync (prevents triggering "unsaved" state)
    children = [
        (current_direction := Signal("ui_scroll_direction", "down")),
        *_default_strip_children(),
    ]
    if show_save:
        children.append(SaveIndicator())

    return Div(
        *children,
        cls="settings-strip settings-strip--sticky",
        # Persist last scroll direction (ignore "none" when stopped)
        data_scroll=(scroll.direction != "none").then(current_direction.set(scroll.direction)),
        data_class_visible=(current_direction == "up") & (scroll.y > header_height),
    )



def Cell(
    *children,
    cell_id=None,
    cell_num=None,
    total_cells=None,
    show_gutter=True,
    show_run=False,
    show_thread=True,
    show_add_cell=True,
    show_controls=True,
    hide_code=False,
    is_markdown=False,
    content_cls="",
    cls="",
    note=None,
):
    """Complete cell with gutter and content area.

    Active state is driven by the ``$ui_active_cell`` signal (declared in
    ``NotebookLayout``).  Clicks route through ``@starimo('cellClick', …)``
    so the plugin can handle sentinel expand/collapse + selection.
    """
    from starhtml.datastar import Signal

    cell_cls = f"cell {cls}".strip() if cls else "cell"

    cell_children = []
    if show_gutter:
        cell_children.append(Gutter(
            cell_num=cell_num,
            cell_id=cell_id,
            total_cells=total_cells,
            show_run=show_run,
            show_controls=show_controls,
            show_thread=show_thread,
            show_add_cell=show_add_cell,
        ))
    content_attrs = {}
    if note:
        content_attrs["data_note"] = note
    cell_children.append(Div(*children, cls=f"content {content_cls}".strip(), **content_attrs))

    extra_attrs = {}
    if cell_id:
        # Three-state code visibility: "auto" (follow global), "true" (always hide), "false" (always show)
        extra_attrs["data_hide_code"] = "true" if hide_code else "auto"

        ui_active_cell = Signal("ui_active_cell", "")
        extra_attrs["data_attr_cls"] = (ui_active_cell == cell_id).if_("active", "")

        extra_attrs["data_on_click"] = f"@starimo('cellClick', '{cell_id}')"
        extra_attrs["data_cell_type"] = "markdown" if is_markdown else "code"

    return Div(
        *cell_children,
        id=f"cell-{cell_id}" if cell_id else None,
        cls=cell_cls,
        **extra_attrs,
    )



def CellPositionSelect(cell_id: str, cell_num: int | str, total_cells: int):
    num = int(cell_num)
    return Div(
        Span(f"{num:02d}", cls="cell-num-display"),
        Span("▾", cls="cell-num-caret"),
        Select(
            *[Option(f"{i:02d}", value=str(i), selected=(i == num))
              for i in range(1, total_cells + 1)],
            cls="cell-num-select",
            aria_label=f"Move cell {cell_id} to position",
            data_on_change=f"@starimo('moveCell', '{cell_id}', evt.target.value)",
        ),
        cls="cell-num-select-wrapper",
    )


def Gutter(cell_num=None, cell_id=None, total_cells=None, show_run=False, show_controls=False, show_thread=True, show_add_cell=True):
    children = []

    if cell_num is not None:
        if cell_id and total_cells and total_cells > 1:
            children.append(CellPositionSelect(cell_id, cell_num, total_cells))
        else:
            children.append(Span(str(cell_num), cls="cell-num"))

    if show_run and cell_id:
        children.append(Button(
            "▶", cls="run-btn",
            data_on_click=f"@starimo('runCell', '{cell_id}')",
        ))

    if show_thread and show_controls and cell_id:
        children.append(GutterThreadToggle(cell_id))
    elif show_thread:
        children.append(Div(cls="gutter-thread"))

    if show_add_cell and cell_id:
        children.append(Button(
            "+", cls="add-cell-btn",
            data_on_click=f"@starimo('addCell', '{cell_id}')",
            title="Add cell below",
        ))

    return Div(*children, cls="gutter")


def GutterThreadToggle(cell_id):
    """Thread line with toggle cap — filled=visible, hollow=hidden.

    Uses ``stop=True`` modifier to prevent the click from bubbling to the
    Cell's ``cellClick`` handler (which would re-expand a just-collapsed sentinel).
    """
    return Div(
        Span(cls="thread-cap"),
        Div(cls="thread-line"),
        cls="gutter-thread-toggle",
        data_on_click=(f"@starimo('toggleHideCode', '{cell_id}')", dict(stop=True)),
        title="Click to show/hide code",
        role="switch",
        aria_label="Toggle code visibility",
    )



def CodeToggle(cell_id):
    """State controlled by parent Cell's data-hide-code via CSS."""
    return Button(
        Span(cls="toggle-thumb"),
        cls="toggle-switch",
        data_on_click=f"@starimo('toggleHideCode', '{cell_id}')",
        title="Toggle code visibility",
        aria_label="Toggle code visibility",
        role="switch",
    )


def CellTypeSelect(cell_id, cell_type="code"):
    display_text = "Markdown" if cell_type == "markdown" else "Code"
    return Div(
        Span(display_text, cls="cell-type-display"),
        Span("▾", cls="cell-type-caret"),
        Select(
            Option("Code", value="code", selected=(cell_type == "code")),
            Option("Markdown", value="markdown", selected=(cell_type == "markdown")),
            cls="cell-type-select",
            data_on_change=f"@starimo('setCellType', '{cell_id}', evt.target.value)",
        ),
        cls="cell-type-select-wrapper",
    )


def CodeHeader(cell_id=None, cell_type="code"):
    if cell_id:
        return Div(CellTypeSelect(cell_id, cell_type), cls="code-header")
    label = "Markdown" if cell_type == "markdown" else "Code"
    return Div(Span(label), cls="code-header")


def CodeBlockControlsTop(cell_id, show_toggle=False, show_status=False):
    from starhtml.datastar import Signal, match

    children = []

    if show_status:
        status = Signal(f"{cell_id}_status", "")
        children.append(Span(
            cls="status-dot",
            data_attr_cls=match(status,
                running="status-dot--running",
                queued="status-dot--queued",
                stale="status-dot--stale",
                error="status-dot--error",
            ),
        ))

    if show_toggle:
        children.append(CodeToggle(cell_id))

    return Div(*children, cls="code-block-controls-top") if children else None


_AUTO_NAME_RE = re.compile(r'cell_[0-9a-f]+$')


def CodeBlockControlsBottom(cell_id, show_cell_name=False):
    from starhtml.plugins import clipboard

    children = [
        Button(Icon("lucide:copy"), cls="code-copy-btn",
            data_on_click=clipboard(text=js("el.closest('.code-construction').querySelector('code-editor').value")),
            title="Copy code", aria_label="Copy code"),
    ]

    if show_cell_name:
        # Auto-generated names hidden at rest; custom names stay visible (CSS uses data-auto-name)
        auto_attr = {"data_auto_name": "true"} if _AUTO_NAME_RE.fullmatch(cell_id) else {}
        children.append(
            Input(
                type="text", value=cell_id, cls="cell-name-input",
                placeholder="cell_name", aria_label=f"Rename cell {cell_id}",
                title=cell_id,
                data_on_blur=f"@starimo('renameCell', '{cell_id}', evt.target.value)",
                data_on_keydown="evt.key === 'Enter' && evt.target.blur()",
                **auto_attr,
            ),
        )

    children.append(
        Button(Icon("lucide:x"), cls="code-delete-btn",
            data_on_click=f"@starimo('{ACTION_DELETE_CELL}', '{cell_id}')",
            title="Delete cell", aria_label="Delete cell"),
    )

    return Div(*children, cls="code-block-controls-bottom")


def CodeBlock(
    code="",
    cell_id=None,
    editable=False,
    show_status=False,
    show_toggle=False,
    show_delete=False,
    is_markdown=False,
    show_cell_name=False,
    autofocus=False,
    cls="",
):
    """Code block with optional editing, status, and controls.

    Code is submitted via form on Run — no signals for content.
    Visibility (hide_code) is controlled by parent Cell's data-hide-code attribute.
    """
    cell_type = "markdown" if is_markdown else "code"

    top_controls = None
    if cell_id and (show_toggle or show_status):
        top_controls = CodeBlockControlsTop(cell_id, show_toggle, show_status)

    bottom_controls = None
    if cell_id and (show_delete or show_cell_name):
        bottom_controls = CodeBlockControlsBottom(cell_id, show_cell_name=show_cell_name)

    if editable and cell_id:
        line_count = code.count("\n") + 1
        wrap_attrs = {"cls": "code-editor-wrap"}
        expand_hint = None
        if line_count > _OVERFLOW_THRESHOLD:
            expanded = Signal("ui_expanded", {})[cell_id]
            wrap_attrs["data_overflows"] = "true"
            wrap_attrs["data_class_expanded"] = expanded
            expand_hint = Span(
                f"{line_count} lines",
                cls="code-expand-hint",
                data_text=expanded.if_("collapse", f"{line_count} lines"),
                data_on_click=[
                    expanded.toggle(),
                    set_timeout(scroll_to(el.closest('.code-editor-wrap'), duration=600, offset=48), 50),
                ],
            )

        return Div(
            Div(
                CodeHeader(cell_id, cell_type),
                Div(
                    Pre(code, cls="cm-fallback"),
                    CodeEditor(
                        value=code,
                        lang="markdown" if is_markdown else "python",
                        id=f"code-{cell_id}",
                        data_on_change=(ui_save_state.set("unsaved"), dict(trusted=True)),
                        data_on_run=(f"@starimo('runCell', '{cell_id}')", dict(trusted=True)),
                        data_ignore_morph="",
                        **({"autofocus": ""} if autofocus else {}),
                    ),
                    expand_hint,
                    **wrap_attrs,
                ),
                id=f"form-{cell_id}",
            ),
            top_controls,
            bottom_controls,
            cls=f"code-construction {cls}".strip(),
        )

    return Div(
        CodeHeader(cell_id, cell_type),
        Div(code, cls="code-editor"),
        top_controls,
        bottom_controls,
        cls=f"code-construction {cls}".strip(),
    )



def _truncate_name(name: str, max_len: int = 20) -> str:
    return name[:max_len] + "\u2026" if len(name) > max_len else name


def OutputTargetSelect(cell_id, all_cells, output_target=None):
    display = f"\u2192 {_truncate_name(output_target)}" if output_target else ""
    options = [
        Option("This Cell", value="", selected=(not output_target)),
        *[Option(f"{_truncate_name(cid)} ({num:02d})", value=cid, selected=(cid == output_target))
          for cid, num in (all_cells or []) if cid != cell_id],
    ]
    return Div(
        Span(display, cls="output-target-display"),
        Icon("lucide:chevron-down", cls="output-target-caret"),
        Select(*options, cls="output-target-select",
            aria_label=f"Redirect output of {cell_id}",
            data_on_change=f"@starimo('setOutputTarget', '{cell_id}', evt.target.value)"),
        cls="output-target-select-wrapper",
    )


def CellMetaRow(cell_id, note=None, output_target=None, all_cells=None):
    from starhtml.plugins import clipboard

    left = [
        Input(
            type="text", value=note or "", cls="cell-note-input",
            placeholder="Add note\u2026",
            data_on_blur=f"const _c = evt.target.closest('.content'); _c.dataset.note = evt.target.value; delete _c.dataset.autoNote; @starimo('setNote', '{cell_id}', evt.target.value)",
            data_on_keydown="evt.key === 'Enter' && evt.target.blur()",
        ),
    ]
    right = []
    if all_cells:
        right.append(OutputTargetSelect(cell_id, all_cells, output_target=output_target))
    right.append(Button(
        Icon("lucide:copy"), cls="output-copy-btn",
        data_on_click=clipboard(element=f"#output-content-{cell_id}"),
        title="Copy output", aria_label="Copy output",
    ))

    return Div(
        Div(*left, cls="cell-meta-left"),
        Div(*right, cls="cell-meta-right"),
        cls="cell-meta-row",
    )


def OutputBlock(*children, cell_id=None, is_markdown=False, cls="", placeholder="Run cell to see output"):
    """output-content (SSE target) + output-annex (portal receiver)."""
    if not children or (len(children) == 1 and children[0] is None):
        content = Span(placeholder, cls="output-placeholder")
    else:
        content = children

    content_div = Div(
        content,
        id=f"output-content-{cell_id}" if cell_id else None,
        cls="output-content",
    )

    block_children = [content_div]
    if cell_id:
        block_children.append(Div(
            id=f"output-annex-{cell_id}",
            cls="output-annex",
        ))

    block_cls = "prose-output" if is_markdown else "output-block"
    if cls:
        block_cls = f"{block_cls} {cls}"

    return Div(
        *block_children,
        id=f"output-{cell_id}" if cell_id else None,
        cls=block_cls,
    )


__all__ = [
    "NotebookLayout",
    "NotebookHeader",
    "EditableTitle",
    "EditableDescription",
    "SettingsPill",
    "ActionPill",
    "StripSeparator",
    "SaveIndicator",
    "SettingsStrip",
    "StickySettingsStrip",
    "CodeToggle",
    "CellTypeSelect",
    "CellPositionSelect",
    "OutputTargetSelect",
    "CellMetaRow",
    "Gutter",
    "Cell",
    "CodeHeader",
    "CodeBlock",
    "OutputBlock",
    "CellsContainer",
    "ThemeToggle",
]
