"""Rationalist Notebook UI — default app for `starimo serve`."""

from starhtml import Script, star_app
from starhtml import iconify_script
from starhtml.plugins import clipboard, katex, mermaid, persist, scroll
from starimo import StarimoPlugin
from starimo.ui.editor import CodeEditor
from starimo.ui.themes.rationalist_v1.components import (
    NotebookLayout,
    NotebookHeader,
    CellsContainer,
)


def create_app(notebook: str):
    """Create a StarHTML app serving a notebook with the rationalist_v1 theme."""
    mo = StarimoPlugin(
        notebook=notebook,
        theme="rationalist_v1",
        auto_run=True,
    )

    app, rt = star_app(
        title="Starimo",
        hdrs=(
            # Early theme detection — runs in <head> before first paint
            Script(
                "const s=localStorage.theme;"
                "if(s==='dark'||(!s&&matchMedia('(prefers-color-scheme:dark)').matches))"
                "document.documentElement.setAttribute('data-theme','dark');"
                "else document.documentElement.setAttribute('data-theme','light');"
            ),
            Script(src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"),
            iconify_script(),
        ),
    )
    app.register(mo, clipboard, katex, mermaid, persist, scroll, CodeEditor)

    @rt("/")
    def home():
        return NotebookLayout(
            NotebookHeader(
                title_signal=mo.notebook_title,
                desc_signal=mo.notebook_description,
            ),
            CellsContainer(),
            data_starimo=True,
            data_notebook_hash=mo.notebook_hash,
        )

    return app
