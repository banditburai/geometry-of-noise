"""Rationalist Notebook Theme v1.

Usage via plugin (preferred — injects CSS automatically):
    mo = StarimoPlugin(notebook="app.py", theme="rationalist_v1")

Manual usage:
    from starimo.ui.themes import rationalist_v1

    app, rt = star_app(hdrs=(
        NotStr(rationalist_v1.FONT_LINKS),
        Style(rationalist_v1.STYLES),
    ))
"""

from pathlib import Path

THEME_NAME = "rationalist_v1"

FONT_LINKS = """
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DotGothic16&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
"""

FONT_IMPORTS = "@import url('https://fonts.googleapis.com/css2?family=DotGothic16&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');"

STYLES = (Path(__file__).parent / "styles.css").read_text()

# Tailwind v4 puts utilities in @layer utilities. We wrap theme styles in
# @layer components (lower priority) so Tailwind classes can override them.
# CSS variables stay outside layers so they're always available.
_vars_end = STYLES.index("/* === Base === */")
_css_variables = STYLES[:_vars_end].split("*/", 1)[1].strip()
_css_rest = STYLES[_vars_end:]

CRITICAL_CSS = FONT_IMPORTS + f"""
{_css_variables}

@layer components {{
{_css_rest}
}}
"""

from starimo.ui.themes.rationalist_v1.renderer import RationalistRenderer

RENDERER = RationalistRenderer()

__all__ = [
    "THEME_NAME",
    "FONT_LINKS",
    "FONT_IMPORTS",
    "STYLES",
    "CRITICAL_CSS",
    "RENDERER",
]
