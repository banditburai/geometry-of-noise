"""Rationalist v1 theme renderer."""

from starhtml import Div

from starimo.renderer import DefaultRenderer
from starimo.ui.themes.rationalist_v1.components import Cell, CellMetaRow, CodeBlock, OutputBlock


class RationalistRenderer(DefaultRenderer):
    """Renders cells using rationalist theme components."""

    pre_code_class = "code-pre"
    pre_error_class = "error-pre"
    error_container_class = "error-block"
    error_type_class = "error-type"
    error_item_class = "error-item"
    install_button_class = "install-btn"
    install_status_class = "install-status"
    table_footer_class = "table-footer"
    json_output_class = "json-output"
    unsupported_class = "unsupported-component"
    image_class = "output-image"

    def __init__(self):
        super().__init__()
        self._next_cell_num = 1

    def reset_cell_counter(self):
        self._next_cell_num = 1

    def render_editable_cell(
        self, cell_id, initial_code="", hide_code=False, *,
        is_markdown=False, autofocus=False,
        total_cells=None, all_cells=None,
        note=None, output_target=None,
    ):
        cell_num = self._next_cell_num
        self._next_cell_num += 1

        return Cell(
            CodeBlock(
                initial_code,
                cell_id=cell_id,
                editable=True,
                show_delete=True,
                is_markdown=is_markdown,
                show_cell_name=True,
                autofocus=autofocus,
            ),
            Div(
                CellMetaRow(cell_id, note=note, output_target=output_target, all_cells=all_cells),
                OutputBlock(cell_id=cell_id, is_markdown=is_markdown),
                cls="output-rail",
            ),
            cell_id=cell_id,
            cell_num=f"{cell_num:02d}",
            total_cells=total_cells or cell_num,
            show_run=True,
            show_controls=True,
            hide_code=hide_code,
            show_thread=True,
            is_markdown=is_markdown,
            note=note,
        )
