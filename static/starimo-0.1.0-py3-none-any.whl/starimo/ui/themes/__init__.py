"""Starimo Themes — theme registry and loader.

Each theme package provides: THEME_NAME, FONT_LINKS, STYLES, CRITICAL_CSS, RENDERER.

Usage:
    from starimo.ui.themes import get_theme
    theme = get_theme("rationalist_v1")
"""

from types import ModuleType

from . import rationalist_v1

_THEMES: dict[str, ModuleType] = {
    "rationalist_v1": rationalist_v1,
}

DEFAULT_THEME = "rationalist_v1"


def get_theme(name: str | None = None) -> ModuleType:
    """Get a theme module by name (defaults to DEFAULT_THEME)."""
    if name is None:
        name = DEFAULT_THEME
    if name not in _THEMES:
        available = ", ".join(_THEMES.keys())
        raise KeyError(f"Theme '{name}' not found. Available: {available}")
    return _THEMES[name]


def list_themes() -> list[str]:
    """List available theme names."""
    return list(_THEMES.keys())


def register_theme(name: str, module: ModuleType) -> None:
    """Register a custom theme module."""
    _THEMES[name] = module


__all__ = [
    "rationalist_v1",
    "get_theme",
    "list_themes",
    "register_theme",
    "DEFAULT_THEME",
]
