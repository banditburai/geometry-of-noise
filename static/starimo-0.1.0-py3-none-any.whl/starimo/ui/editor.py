"""CodeMirror 6 editor web component for Starimo notebook cells."""

from starhtml import Div, Script

from starelements import Local, element

# --- CodeMirror dependency maps ---
# unpkg serves raw ESM with bare imports; we must map ALL transitive deps.

CM_IMPORT_MAP = {
    "@codemirror/state": "https://unpkg.com/@codemirror/state@6.4.1/dist/index.js",
    "@codemirror/view": "https://unpkg.com/@codemirror/view@6.28.1/dist/index.js",
    "@codemirror/language": "https://unpkg.com/@codemirror/language@6.10.1/dist/index.js",
    "@codemirror/commands": "https://unpkg.com/@codemirror/commands@6.5.0/dist/index.js",
    "@codemirror/autocomplete": "https://unpkg.com/@codemirror/autocomplete@6.16.0/dist/index.js",
    "@codemirror/search": "https://unpkg.com/@codemirror/search@6.5.6/dist/index.js",
    "@codemirror/lint": "https://unpkg.com/@codemirror/lint@6.8.1/dist/index.js",
    "@codemirror/lang-python": "https://unpkg.com/@codemirror/lang-python@6.1.6/dist/index.js",
    "@codemirror/lang-javascript": "https://unpkg.com/@codemirror/lang-javascript@6.2.2/dist/index.js",
    "@codemirror/lang-markdown": "https://unpkg.com/@codemirror/lang-markdown@6.2.5/dist/index.js",
    # Transitive deps of lang-markdown → lang-html → lang-css
    "@codemirror/lang-html": "https://unpkg.com/@codemirror/lang-html@6.4.11/dist/index.js",
    "@codemirror/lang-css": "https://unpkg.com/@codemirror/lang-css@6.3.1/dist/index.js",
    "@lezer/common": "https://unpkg.com/@lezer/common@1.2.1/dist/index.js",
    "@lezer/highlight": "https://unpkg.com/@lezer/highlight@1.2.0/dist/index.js",
    "@lezer/lr": "https://unpkg.com/@lezer/lr@1.4.0/dist/index.js",
    "@lezer/python": "https://unpkg.com/@lezer/python@1.1.14/dist/index.js",
    "@lezer/javascript": "https://unpkg.com/@lezer/javascript@1.4.14/dist/index.js",
    "@lezer/markdown": "https://unpkg.com/@lezer/markdown@1.3.0/dist/index.js",
    "@lezer/html": "https://unpkg.com/@lezer/html@1.3.13/dist/index.js",
    "@lezer/css": "https://unpkg.com/@lezer/css@1.3.0/dist/index.js",
    "style-mod": "https://unpkg.com/style-mod@4.1.0/src/style-mod.js",
    "w3c-keyname": "https://unpkg.com/w3c-keyname@2.2.8/index.js",
    "crelt": "https://unpkg.com/crelt@1.0.6/index.js",
}

CM_IMPORTS = {
    "state": "@codemirror/state",
    "view": "@codemirror/view",
    "language": "@codemirror/language",
    "commands": "@codemirror/commands",
    "highlight": "@lezer/highlight",
    "lang_python": "@codemirror/lang-python",
    "lang_markdown": "@codemirror/lang-markdown",
}


@element(
    "code-editor",
    skeleton=False,
    imports=CM_IMPORTS,
    import_map=CM_IMPORT_MAP,
)
def CodeEditor():
    """CodeMirror 6 editor for notebook cells.

    Attributes (set via data_attr_*):
        value: Initial code content
        lang: "python" or "markdown"
        autofocus: if present, focuses editor after mount

    Events emitted:
        change: {detail: {value}} on doc change
        run: {} on Shift+Enter

    Properties:
        .value (get/set): read or replace editor content
    """
    value = Local("value", "")
    lang = Local("lang", "python")

    return Div(
        value,
        lang,
        Script("""
            const _id = el.id || 'unknown';

            if (!state || !view || !commands || !language) {
                console.error(`[CodeEditor:${_id}] MISSING CM deps — aborting setup`);
                return;
            }

            const { EditorState, Compartment } = state;
            const { EditorView, keymap, lineNumbers, highlightActiveLine,
                    highlightActiveLineGutter, drawSelection } = view;
            const { defaultKeymap, history, historyKeymap, indentWithTab } = commands;
            const { syntaxHighlighting, HighlightStyle, indentOnInput,
                    bracketMatching, codeFolding, foldGutter, foldKeymap,
                    foldNodeProp, foldInside, LanguageSupport,
                    foldedRanges, foldEffect, foldState } = language;
            const { tags } = highlight || {};

            if (!tags) {
                console.error(`[CodeEditor:${_id}] highlight.tags missing`);
                return;
            }

            function fnv1a(str) {
                let h = 0x811c9dc5;
                for (let i = 0; i < str.length; i++) {
                    h ^= str.charCodeAt(i);
                    h = Math.imul(h, 0x01000193);
                }
                return h >>> 0;
            }
            const _nbHash = el.closest('[data-notebook-hash]')?.dataset?.notebookHash || '';
            const FOLDS_KEY = 'starimo-folds' + (_nbHash ? '-' + _nbHash : '');
            function loadFolds() {
                try { return JSON.parse(localStorage.getItem(FOLDS_KEY) || '{}'); }
                catch { return {}; }
            }
            function saveFolds(data) {
                try { localStorage.setItem(FOLDS_KEY, JSON.stringify(data)); }
                catch {}
            }

            const lightStyle = HighlightStyle.define([
                { tag: tags.keyword, fontWeight: '700' },
                { tag: tags.controlKeyword, fontWeight: '700' },
                { tag: tags.definitionKeyword, fontWeight: '700' },
                { tag: tags.operatorKeyword, fontWeight: '700' },
                { tag: [tags.function(tags.variableName),
                        tags.function(tags.definition(tags.variableName))],
                  color: '#9a3412' },
                { tag: tags.definition(tags.variableName), color: '#1e3a5f' },
                { tag: tags.variableName, color: '#050505' },
                { tag: [tags.className, tags.definition(tags.className)],
                  color: '#9a3412', fontWeight: '600' },
                { tag: tags.propertyName, color: '#4a5568' },
                { tag: [tags.string, tags.special(tags.string)], color: '#737373' },
                { tag: tags.number, color: '#6b21a8' },
                { tag: tags.bool, color: '#6b21a8' },
                { tag: tags.comment, color: '#9ca3af', fontStyle: 'italic' },
                { tag: tags.operator, color: '#050505' },
                { tag: tags.punctuation, color: '#737373' },
                { tag: tags.self, fontWeight: '600', fontStyle: 'italic' },
                { tag: [tags.meta, tags.annotation], color: '#9ca3af' },
            ]);

            const darkStyle = HighlightStyle.define([
                { tag: tags.keyword, fontWeight: '700', color: '#E8E8E8' },
                { tag: tags.controlKeyword, fontWeight: '700', color: '#E8E8E8' },
                { tag: tags.definitionKeyword, fontWeight: '700', color: '#E8E8E8' },
                { tag: tags.operatorKeyword, fontWeight: '700', color: '#E8E8E8' },
                { tag: [tags.function(tags.variableName),
                        tags.function(tags.definition(tags.variableName))],
                  color: '#FFA07A' },
                { tag: tags.definition(tags.variableName), color: '#87CEEB' },
                { tag: tags.variableName, color: '#D4D4D4' },
                { tag: [tags.className, tags.definition(tags.className)],
                  color: '#FFA07A', fontWeight: '600' },
                { tag: tags.propertyName, color: '#A0AEC0' },
                { tag: [tags.string, tags.special(tags.string)], color: '#A0A0A0' },
                { tag: tags.number, color: '#CE93D8' },
                { tag: tags.bool, color: '#CE93D8' },
                { tag: tags.comment, color: '#666666', fontStyle: 'italic' },
                { tag: tags.operator, color: '#D4D4D4' },
                { tag: tags.punctuation, color: '#888888' },
                { tag: tags.self, fontWeight: '600', fontStyle: 'italic', color: '#D4D4D4' },
                { tag: [tags.meta, tags.annotation], color: '#666666' },
            ]);

            const syntaxStyle = new Compartment();
            const langConfig = new Compartment();
            const isDark = () => document.documentElement.getAttribute('data-theme') === 'dark';
            const getStyle = () => syntaxHighlighting(isDark() ? darkStyle : lightStyle);

            // Pre-compute extended Python language (fold ArgList, ParamList, comprehensions).
            // Built-in foldNodeProp already covers Array/Dict/Set/Tuple/Body.
            const pythonLang = lang_python ? (() => {
                const py = lang_python.python();
                const extLang = py.language.configure({
                    props: [foldNodeProp.add({
                        ArgList: foldInside,
                        ParamList: foldInside,
                        ComprehensionExpression: foldInside,
                        ArrayComprehensionExpression: foldInside,
                        DictionaryComprehensionExpression: foldInside,
                        SetComprehensionExpression: foldInside,
                    })]
                });
                return new LanguageSupport(extLang, py.support);
            })() : null;

            const getLang = (l) => {
                if (l === 'markdown' && lang_markdown) return lang_markdown.markdown();
                if (pythonLang) return pythonLang;
                console.warn(`[CodeEditor:${_id}] no parser for lang=${l}`);
                return [];
            };

            const runKeymap = keymap.of([{
                key: 'Shift-Enter',
                run: () => {
                    el.dispatchEvent(new CustomEvent('run', { bubbles: true }));
                    return true;
                }
            }]);

            const initialDoc = el.getAttribute('value') || '';
            const initialLang = el.getAttribute('lang') || 'python';
            const editorMount = refs('editor');

            if (!editorMount) {
                console.error(`[CodeEditor:${_id}] refs('editor') returned null — cannot mount CM`);
                return;
            }

            // Build state, apply saved folds, then mount — prevents layout shift
            let editorState = EditorState.create({
                doc: initialDoc,
                extensions: [
                    lineNumbers(),
                    highlightActiveLineGutter(),
                    history(),
                    drawSelection(),
                    highlightActiveLine(),
                    indentOnInput(),
                    bracketMatching(),
                    codeFolding(),
                    foldGutter({ openText: '\u25BE', closedText: '\u25B8' }),
                    keymap.of([...foldKeymap, indentWithTab, ...defaultKeymap, ...historyKeymap]),
                    runKeymap,
                    langConfig.of(getLang(initialLang)),
                    syntaxStyle.of(getStyle()),
                    EditorView.theme({
                        "&": { height: "auto" },
                    }),
                    EditorView.updateListener.of(update => {
                        if (update.docChanged) {
                            el.dispatchEvent(new CustomEvent('change', {
                                detail: { value: update.state.doc.toString() },
                                bubbles: true,
                            }));
                        }
                        if (update.startState.field(foldState, false)
                            !== update.state.field(foldState, false)) {
                            const doc = update.state.doc.toString();
                            const folds = [];
                            foldedRanges(update.state).between(0, doc.length, (from, to) => {
                                folds.push(from, to);
                            });
                            const all = loadFolds();
                            if (folds.length > 0) {
                                all[_id] = { h: fnv1a(doc), f: folds };
                            } else {
                                delete all[_id];
                            }
                            saveFolds(all);
                        }
                    }),
                ],
            });

            {
                const allFolds = loadFolds();
                const saved = allFolds[_id];
                if (saved && saved.h === fnv1a(initialDoc) && saved.f && saved.f.length > 0) {
                    const effects = [];
                    for (let i = 0; i < saved.f.length; i += 2) {
                        const from = saved.f[i], to = saved.f[i + 1];
                        if (from < initialDoc.length && to <= initialDoc.length) {
                            effects.push(foldEffect.of({ from, to }));
                        }
                    }
                    if (effects.length > 0) {
                        editorState = editorState.update({ effects }).state;
                    }
                }
            }

            const view_inst = new EditorView({
                state: editorState,
                parent: editorMount,
            });

            // .value property for imperative read/write from TS plugin
            Object.defineProperty(el, 'value', {
                get() { return view_inst.state.doc.toString(); },
                set(v) {
                    const current = view_inst.state.doc.toString();
                    if (v !== current) {
                        view_inst.dispatch({
                            changes: { from: 0, to: current.length, insert: v },
                        });
                    }
                },
                configurable: true,
            });

            effect(() => {
                view_inst.dispatch({
                    effects: langConfig.reconfigure(getLang($$lang)),
                });
            });

            // React to external value pushes (SSE setAttribute → signal change)
            let lastPushedValue = initialDoc;
            effect(() => {
                const currentValue = $$value;
                if (currentValue !== undefined && currentValue !== lastPushedValue) {
                    lastPushedValue = currentValue;
                    const currentDoc = view_inst.state.doc.toString();
                    if (currentValue !== currentDoc) {
                        view_inst.dispatch({
                            changes: { from: 0, to: currentDoc.length, insert: currentValue },
                        });
                    }
                }
            });

            const themeObserver = new MutationObserver(() => {
                view_inst.dispatch({
                    effects: syntaxStyle.reconfigure(getStyle()),
                });
            });
            themeObserver.observe(document.documentElement, {
                attributes: true, attributeFilter: ['data-theme'],
            });

            // Autofocus support — deferred to next frame because starelements
            // restores visibility in the finally block AFTER _runSetup
            if (el.hasAttribute('autofocus')) {
                requestAnimationFrame(() => view_inst.focus());
            }

            onCleanup(() => { themeObserver.disconnect(); view_inst.destroy(); });
        """),
        Div(data_ref="editor"),
    )


__all__ = ["CodeEditor"]
