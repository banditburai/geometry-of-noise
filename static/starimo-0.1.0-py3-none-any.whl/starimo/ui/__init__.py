"""Starimo UI — theme system for notebook interfaces."""

from . import themes

__all__ = ["themes"]
