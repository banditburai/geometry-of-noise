"""Marimo WebSocket bridge — maintains kernel connection, cell tracking, and signal sync."""


import asyncio
import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Any

import httpx

from .core import (
    STARIMO_PREAMBLE_NAME,
    STARIMO_SEED_BOOTSTRAP_CODE,
    STARIMO_SEED_NAME,
    STARIMO_SIGNAL_SYNC_NAME,
    STARIMO_UI_PREAMBLE_CODE,
    CellInfo,
    SeedCellGuard,
    SignalRegistry,
    cleanup_cell_signals,
    display_math_to_dollars,
    ensure_raw_md_string,
    extract_starimo_values,
    find_seed_cell,
    is_markdown,
    mermaid_fences_to_divs,
    parse_names,
    parse_variable_value,
    unwrap_markdown,
    update_starimo_values_code,
    validate_cell_name,
)

_MISSING = object()

logger = logging.getLogger(__name__)


def _dig(obj: Any, *attrs: str, default: Any = None) -> Any:
    """Chase a chain of getattr calls, returning default if any is None."""
    for attr in attrs:
        if obj is None:
            return default
        obj = getattr(obj, attr, None)
    return obj if obj is not None else default


def _as_list(val: Any) -> list:
    """Normalize marimo's occasional object-style arrays to lists."""
    if isinstance(val, dict):
        return [val.get(str(i)) for i in range(len(val))]
    return val


def _store_code(code: str) -> tuple[str, bool]:
    is_md = is_markdown(code)
    if is_md:
        raw = unwrap_markdown(code)
        if raw is not None:
            return raw, True
    return code, is_md


@dataclass
class MarimoBridge:
    """Cells are keyed by function name (canonical ID). A separate mapping
    tracks function_name → runtime_id for marimo API calls.
    """

    marimo_url: str = "ws://localhost:2718/ws"
    marimo_http_url: str = "http://localhost:2718"
    notebook_path: Path | None = None
    auto_run_stale: bool = True

    # Callbacks wired by plugin.py → relay
    on_variables_batch: Callable[[dict[str, Any]], None] | None = None
    on_cell_output: Callable[[str, dict], None] | None = None
    on_cell_status: Callable[[str, str, Any], None] | None = None
    on_cell_code_change: Callable[[str, str], None] | None = None
    on_cell_deleted: Callable[[str], None] | None = None
    on_ready: Callable[[], None] | None = None

    _ws: Any = None
    _http: httpx.AsyncClient | None = None
    _session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    _server_token: str | None = None
    _connected: bool = False
    _ready: bool = False
    _resumed: bool = False
    _listen_task: asyncio.Task | None = None

    _cells: dict[str, CellInfo] = field(default_factory=dict)
    _name_to_runtime_id: dict[str, str] = field(default_factory=dict)
    _runtime_id_to_name_map: dict[str, str] = field(default_factory=dict)
    _original_cell_names: set[str] = field(default_factory=set)
    _all_defs: set[str] = field(default_factory=set)
    _all_refs: set[str] = field(default_factory=set)
    _cells_awaiting_output: set[str] = field(default_factory=set)

    _signal_registry: SignalRegistry = field(default_factory=SignalRegistry)
    _output_variables: set[str] = field(default_factory=set)

    _seed_guard: SeedCellGuard | None = None
    _seed_initialized: bool = False

    # Prevents rapid sync from overwhelming the kernel
    _run_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _run_requested: bool = False

    # Once set, permanently preserves user's visual order over kernel dependency order
    _user_reordered: bool = False

    # ── ID mapping helpers ────────────────────────────────────────────

    def _register_cell_id(self, name: str, runtime_id: str) -> None:
        self._name_to_runtime_id[name] = runtime_id
        self._runtime_id_to_name_map[runtime_id] = name

    def _unregister_cell_id(self, name: str) -> None:
        rid = self._name_to_runtime_id.pop(name, None)
        if rid:
            self._runtime_id_to_name_map.pop(rid, None)

    def _resolve_name(self, runtime_id: str | None) -> str | None:
        if not runtime_id:
            return None
        if runtime_id in self._runtime_id_to_name_map:
            return self._runtime_id_to_name_map[runtime_id]
        # Dynamic cells may use their name as runtime_id
        if runtime_id in self._cells:
            return runtime_id
        return None

    def _rebuild_cell_order(self, user_keys: list[str]) -> None:
        system = {k: self._cells[k] for k in self._cells if k.startswith("_starimo_")}
        self._cells = {**system, **{k: self._cells[k] for k in user_keys}}
        self._user_reordered = True

    # ── Connection lifecycle ──────────────────────────────────────────

    def _load_cell_metadata(self) -> None:
        if self.notebook_path is None or not self.notebook_path.exists():
            return

        try:
            from marimo._ast.load import load_app

            app = load_app(self.notebook_path)
            for cell_data in app._cell_manager.cell_data():  # type: ignore[union-attr]
                runtime_id = cell_data.cell_id  # type: ignore[union-attr]
                name = cell_data.name  # type: ignore[union-attr]
                code = cell_data.code  # type: ignore[union-attr]

                if name == STARIMO_SIGNAL_SYNC_NAME:
                    continue

                hide_code = _dig(cell_data.cell, '_cell', 'config', 'hide_code', default=False)

                if cell_data.cell is not None:
                    self._all_defs.update(cell_data.cell.defs)  # type: ignore[union-attr]
                    self._all_refs.update(cell_data.cell.refs)  # type: ignore[union-attr]

                self._original_cell_names.add(name)
                self._register_cell_id(name, runtime_id)

                stored_code, is_md = _store_code(code)
                self._cells[name] = CellInfo(
                    id=name, code=stored_code, name=name,
                    hide_code=hide_code, is_markdown=is_md,
                    defs=set(cell_data.cell.defs) if cell_data.cell else set(),
                )

            logger.debug(f"Loaded {len(self._cells)} cells from file")
        except Exception as e:
            logger.warning(f"Could not load cell metadata: {e}")

    def _apply_cell_notes(self) -> None:
        seed_cell = find_seed_cell(self._cells)
        if not seed_cell:
            return
        cell_notes = extract_starimo_values(seed_cell.code).get('cell_notes', {})
        if isinstance(cell_notes, dict):
            for cell_id, note in cell_notes.items():
                if cell_id in self._cells and isinstance(note, str):
                    self._cells[cell_id].note = note

    async def connect(self) -> None:
        import websockets

        self._load_cell_metadata()
        self._http = httpx.AsyncClient(base_url=self.marimo_http_url)

        url = f"{self.marimo_url}?session_id={self._session_id}"
        logger.debug(f"Connecting to Marimo: {url}")

        try:
            self._ws = await websockets.connect(url)
            self._connected = True
            logger.info("Connected to Marimo")
            self._listen_task = asyncio.create_task(self._listen())
        except Exception as e:
            logger.error(f"Failed to connect: {e}")
            raise

    async def disconnect(self) -> None:
        self._connected = False
        if self._listen_task:
            self._listen_task.cancel()
            try:
                await self._listen_task
            except asyncio.CancelledError:
                pass
        if self._ws:
            await self._ws.close()
            self._ws = None
        if self._http:
            await self._http.aclose()
            self._http = None

    async def wait_ready(self, timeout: float = 30.0) -> None:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        while not self._ready:
            if loop.time() > deadline:
                raise TimeoutError("Kernel did not become ready")
            await asyncio.sleep(0.1)

    # ── WebSocket message handling ────────────────────────────────────

    async def _listen(self) -> None:
        try:
            async for message in self._ws:
                try:
                    await self._handle_message(json.loads(message))
                except json.JSONDecodeError:
                    logger.warning(f"Invalid JSON: {message[:100]}")
                except Exception as e:
                    logger.error(f"Error handling message: {e}")
        except Exception as e:
            if self._connected:
                logger.error(f"WebSocket error: {e}")
                self._connected = False

    async def _handle_message(self, data: dict[str, Any]) -> None:
        op = data.get("op")
        payload = data.get("data", data)

        match op:
            case "kernel-ready":
                await self._handle_kernel_ready(payload)
            case "cell-op":
                output = payload.get('output')
                if output and isinstance(output, dict):
                    if output.get('traceback'):
                        logger.error(f"Cell error ({payload.get('cell_id')}): {output.get('traceback')}")
                    if output.get('channel') == 'marimo-error':
                        logger.error(f"Cell marimo-error ({payload.get('cell_id')}): {output}")
                await self._handle_cell_op(payload)
            case "variable-values":
                await self._handle_variable_values(payload)
            case "update-cell-codes":
                await self._handle_update_cell_codes(payload)
            case "alert":
                logger.warning(f"Alert: {payload}")
            case _:
                pass

    async def _handle_kernel_ready(self, data: dict[str, Any]) -> None:
        self._resumed = data.get("resumed", False)
        logger.info(f"Kernel ready, resumed={self._resumed}")

        # Marimo sometimes sends object-style arrays instead of lists
        cell_ids = _as_list(data.get("cell_ids", []))
        codes = _as_list(data.get("codes", []))
        names = _as_list(data.get("names", []))

        kernel_order: list[str] = []
        for runtime_id, ws_name, ws_code in zip(cell_ids, names, codes):
            ws_name = ws_name or ""
            ws_code = ws_code or ""
            if not runtime_id:
                continue

            if ws_name:
                self._register_cell_id(ws_name, runtime_id)
                if ws_name not in kernel_order:
                    kernel_order.append(ws_name)

                if ws_name in self._cells:
                    if ws_code and not self._cells[ws_name].code:
                        self._cells[ws_name].code = ws_code
                else:
                    stored_code, is_md = _store_code(ws_code)
                    defs, _ = parse_names(ws_code)
                    self._cells[ws_name] = CellInfo(
                        id=ws_name, code=stored_code, name=ws_name,
                        is_markdown=is_md, defs=defs,
                    )

        # Output variables are computed by marimo and not settable from frontend.
        # Seed cell signals are excluded — they're always settable inputs.
        seed_cell = find_seed_cell(self._cells)
        seed_signals = set()
        if seed_cell and seed_cell.code:
            seed_signals = set(extract_starimo_values(seed_cell.code).keys())
            self._seed_guard = SeedCellGuard(seed_cell.id)
        self._output_variables = (self._all_defs - self._all_refs) - seed_signals

        # Reorder _cells to match kernel's dependency order so SSE
        # restoration sends signal-defining cells before cells that reference them.
        # Skip if user has manually reordered — preserve their visual order.
        if not self._user_reordered:
            for name in list(self._cells.keys()):
                if name not in kernel_order:
                    kernel_order.append(name)
            self._cells = {n: self._cells[n] for n in kernel_order if n in self._cells}

        self._apply_cell_notes()
        self._ready = True
        logger.debug(f"cells={list(self._cells.keys())}, seeds={seed_signals}, outputs={self._output_variables}")

        if self.on_ready:
            self.on_ready()

    async def _handle_cell_op(self, data: dict[str, Any]) -> None:
        runtime_id = data.get("cell_id")
        status = data.get("status")
        output = data.get("output")

        name = self._resolve_name(runtime_id)
        if not name:
            logger.warning(f"cell_op: unknown runtime_id={runtime_id}")
            return

        if name not in self._cells:
            logger.warning(f"cell_op: {name} not in cells")
            return

        cell = self._cells[name]
        if status:
            cell.status = status
            if status in ("running", "queued"):
                self._cells_awaiting_output.add(name)

        if output is not None:
            self._cells_awaiting_output.discard(name)
            if isinstance(output, dict):
                # Marimo JSON-encodes mimebundle data (e.g. matplotlib) — deserialize at transport layer
                mimetype = output.get("mimetype", "?")
                if mimetype == "application/vnd.marimo+mimebundle" and isinstance(output.get("data"), str):
                    try:
                        output = {**output, "data": json.loads(output["data"])}
                    except (json.JSONDecodeError, TypeError):
                        pass
            cell.output = output
            if self.on_cell_output:
                self.on_cell_output(name, output)
        elif status == "idle" and name in self._cells_awaiting_output:
            # Cell finished running without producing output — clear stale output
            self._cells_awaiting_output.discard(name)
            if cell.output is not None:
                cell.output = None
                if self.on_cell_output:
                    self.on_cell_output(name, {"data": "", "mimetype": "text/plain"})

        if self.on_cell_status:
            self.on_cell_status(name, status or cell.status, cell.execution_time)

    async def _handle_variable_values(self, data: dict[str, Any]) -> None:
        variables = data.get("variables", [])
        changed: dict[str, Any] = {}

        for var_info in variables:
            name = var_info.get("name")
            value = var_info.get("value")

            if not name or name.startswith("_"):
                continue

            # Preamble definitions (HTML tags, render helpers) aren't data
            datatype = var_info.get("datatype", "")
            if datatype in ("function", "type", "module", "builtin_function_or_method"):
                continue

            # Object repr strings aren't useful as signal values
            if isinstance(value, str) and value.startswith("<") and " object at 0x" in value:
                continue

            value = parse_variable_value(value)
            if self._signal_registry.set_without_pending(name, value):
                changed[name] = value

        if changed and self.on_variables_batch:
            self.on_variables_batch(changed)

    async def _handle_update_cell_codes(self, data: dict[str, Any]) -> None:
        cell_ids = data.get("cell_ids", [])
        codes = data.get("codes", [])
        code_is_stale = data.get("code_is_stale", True)

        logger.debug(f"File changed: {len(cell_ids)} cells updated (stale={code_is_stale})")

        prev_codes: dict[str, str] = {n: c.code for n, c in self._cells.items()}
        incoming_names: set[str] = set()

        for runtime_id, code in zip(cell_ids, codes):
            name = self._resolve_name(runtime_id)
            if name and name in self._cells:
                stored, is_md = _store_code(code)
                self._cells[name].code = stored
                if is_md:
                    self._cells[name].is_markdown = True
                if code_is_stale:
                    self._cells[name].status = "stale"
                    if self.on_cell_status:
                        self.on_cell_status(name, "stale", None)
                if self.on_cell_code_change and prev_codes.get(name) != stored:
                    self.on_cell_code_change(name, stored)
                incoming_names.add(name)
            elif runtime_id:
                stored, is_md = _store_code(code)
                self._cells[runtime_id] = CellInfo(
                    id=runtime_id, code=stored, name=runtime_id,
                    status="stale" if code_is_stale else "idle",
                    is_markdown=is_md,
                )
                self._register_cell_id(runtime_id, runtime_id)
                incoming_names.add(runtime_id)

        # Only delete cells from the original file — runtime-created cells must survive
        for name in set(self._cells.keys()) - incoming_names:
            if name not in self._original_cell_names:
                continue
            if self.on_cell_deleted:
                self.on_cell_deleted(name)
            self._unregister_cell_id(name)
            del self._cells[name]
            self._original_cell_names.discard(name)

    # ── Marimo HTTP API ───────────────────────────────────────────────

    async def _ensure_server_token(self) -> str:
        # Cache hit (including cached empty string from --no-token mode)
        if self._server_token is not None:
            return self._server_token

        assert self._http, "connect() must be called before HTTP operations"
        response = await self._http.get("/")
        html = response.text

        for pattern in [
            r'"serverToken"\s*:\s*"([^"]+)"',
            r'"server_token"\s*:\s*"([^"]+)"',
            r'Marimo-Server-Token["\s:]+([a-f0-9-]+)',
        ]:
            match = re.search(pattern, html, re.IGNORECASE)
            if match:
                token = match.group(1)
                self._server_token = token
                return token

        # No token found (common with --no-token) — cache to avoid re-fetching
        self._server_token = ""
        return ""

    def _get_api_headers(self, token: str) -> dict[str, str]:
        headers = {"Marimo-Session-Id": self._session_id, "Content-Type": "application/json"}
        if token:
            headers["Marimo-Server-Token"] = token
        return headers

    async def _run_cells_api(self, cell_ids: list[str], codes: list[str], operation: str = "run") -> None:
        token = await self._ensure_server_token()
        headers = self._get_api_headers(token)

        assert self._http, "connect() must be called before HTTP operations"
        response = await self._http.post(
            "/api/kernel/run",
            json={"cellIds": cell_ids, "codes": codes},
            headers=headers,
        )

        if response.status_code != 200:
            logger.error(f"{operation} failed: {response.status_code} - {response.text}")
            raise RuntimeError(f"{operation} failed: {response.text}")

    async def install_package(self, package: str) -> dict:
        token = await self._ensure_server_token()
        headers = self._get_api_headers(token)
        logger.info(f"Installing package: {package}")
        assert self._http, "connect() must be called before HTTP operations"
        response = await self._http.post(
            "/api/packages/add",
            json={"package": package},
            headers=headers,
            timeout=120.0,
        )
        if response.status_code != 200:
            return {"success": False, "error": f"HTTP {response.status_code}: {response.text}"}
        data = response.json()
        if data.get("success") is False:
            return {"success": False, "error": data.get("error", "Install failed")}
        return {"success": True}

    # ── Signal sync ───────────────────────────────────────────────────

    def _build_signal_sync_cell_code(self, signals: dict[str, Any]) -> str:
        lines = ["from starimo.core import call_setter"]
        for name, value in signals.items():
            lines.append(f"call_setter({name!r}, {value!r})")
        return "\n".join(lines)

    async def _sync_signals_to_marimo(self, force: bool = False) -> None:
        """Args:
            force: Sync ALL known values even without pending changes.
                   Ensures registry correctness before cell runs.
        """
        all_signals = self._signal_registry.get_all()
        if not all_signals:
            return
        if not force and not self._signal_registry.has_pending_changes():
            return
        if not self._connected:
            logger.warning("Cannot sync signals - not connected")
            return

        sync_code = self._build_signal_sync_cell_code(all_signals)
        self._signal_registry.clear_pending_changes()

        if STARIMO_SIGNAL_SYNC_NAME not in self._cells:
            self._cells[STARIMO_SIGNAL_SYNC_NAME] = CellInfo(
                id=STARIMO_SIGNAL_SYNC_NAME, code=sync_code, name=STARIMO_SIGNAL_SYNC_NAME,
            )
            self._register_cell_id(STARIMO_SIGNAL_SYNC_NAME, STARIMO_SIGNAL_SYNC_NAME)
            logger.info("Creating signal sync cell")

        runtime_id = self._name_to_runtime_id.get(STARIMO_SIGNAL_SYNC_NAME, STARIMO_SIGNAL_SYNC_NAME)

        try:
            await self._run_cells_api([runtime_id], [sync_code], "Signal sync")
        except Exception as e:
            logger.error(f"Signal sync failed: {e}")

    async def set_input(self, datastar_name: str, value: Any) -> None:
        """Queue a signal for lazy sync to marimo.

        Signals batch here and sync when cells run (run_cell/run_all_cells).
        Does NOT re-run cells — Datastar handles UI reactivity client-side.
        """
        if datastar_name in self._output_variables:
            return

        self._signal_registry.update(datastar_name, value)

    # ── Cell operations ───────────────────────────────────────────────

    def _exec_code(self, name: str) -> str:
        cell = self._cells[name]
        if cell.is_markdown and not is_markdown(cell.code):
            md = display_math_to_dollars(cell.code)
            md = mermaid_fences_to_divs(md)
            return f'mo.md(r"""\n{md}\n""")'
        if cell.is_markdown:
            return ensure_raw_md_string(cell.code)
        return cell.code

    async def run_cell(self, name: str, code: str | None = None) -> None:
        if not self._connected:
            raise RuntimeError("Not connected to Marimo")
        if name not in self._cells:
            raise ValueError(f"Unknown cell: {name}")

        if self._seed_guard:
            self._seed_guard.check_cell(name, "run")

        if code is not None:
            stored, _ = _store_code(code)
            self._cells[name].code = stored

        await self._sync_signals_to_marimo(force=True)

        runtime_id = self._name_to_runtime_id.get(name, name)
        await self._run_cells_api([runtime_id], [self._exec_code(name)], "Run cell")

    def set_note(self, cell_id: str, note: str | None) -> None:
        if cell_id not in self._cells:
            raise ValueError(f"Unknown cell: {cell_id}")
        self._cells[cell_id].note = note or None

    def update_cell(
        self, name: str, code: str | None = None,
        is_markdown: bool | None = None, output_target: Any = _MISSING,
    ) -> None:
        if name not in self._cells:
            raise ValueError(f"Unknown cell: {name}")
        if code is not None:
            stored, _ = _store_code(code)
            self._cells[name].code = stored
        if is_markdown is not None:
            self._cells[name].is_markdown = is_markdown
        if output_target is not _MISSING:
            self._cells[name].output_target = output_target

    def move_cell(self, cell_id: str, position: int) -> None:
        """Position is 1-indexed."""
        keys = [k for k in self._cells if not k.startswith("_starimo_")]
        if cell_id not in keys:
            raise ValueError(f"Unknown cell: {cell_id}")
        keys.remove(cell_id)
        keys.insert(max(0, min(position - 1, len(keys))), cell_id)
        self._rebuild_cell_order(keys)

    def insert_cell(self, cell_id: str, code: str = "", after_cell_id: str | None = None) -> None:
        stored_code, is_md = _store_code(code) if code else (code, False)
        self._cells[cell_id] = CellInfo(
            id=cell_id, code=stored_code, name=cell_id, is_markdown=is_md,
        )
        self._register_cell_id(cell_id, cell_id)

        if after_cell_id and after_cell_id in self._cells:
            keys = [k for k in self._cells if not k.startswith("_starimo_")]
            keys.remove(cell_id)
            keys.insert(keys.index(after_cell_id) + 1, cell_id)
            self._rebuild_cell_order(keys)
        else:
            self._user_reordered = True

    def rename_cell(self, old_name: str, new_name: str) -> None:
        if old_name not in self._cells:
            raise ValueError(f"Unknown cell: {old_name}")
        error = validate_cell_name(new_name, set(self._cells.keys()))
        if error:
            raise ValueError(error)
        new_cells: dict[str, CellInfo] = {}
        for k, v in self._cells.items():
            if k == old_name:
                v.id = new_name
                v.name = new_name
                new_cells[new_name] = v
            else:
                new_cells[k] = v
        self._cells = new_cells
        if old_name in self._name_to_runtime_id:
            rid = self._name_to_runtime_id.pop(old_name)
            self._name_to_runtime_id[new_name] = rid
            self._runtime_id_to_name_map[rid] = new_name
        if old_name in self._original_cell_names:
            self._original_cell_names.discard(old_name)
            self._original_cell_names.add(new_name)
        cleanup_cell_signals(old_name)

    async def run_all_cells(self) -> None:
        """Seed cell is excluded — it creates mo.state instances that must happen
        exactly once. Re-running would orphan existing state.
        """
        if not self._connected:
            raise RuntimeError("Not connected to Marimo")

        await self._sync_signals_to_marimo()

        names_to_run = list(self._cells.keys())
        if self._seed_guard:
            names_to_run = self._seed_guard.filter_cells(names_to_run)

        runtime_ids = [self._name_to_runtime_id.get(n, n) or n for n in names_to_run]
        codes = [self._exec_code(n) for n in names_to_run]
        await self._run_cells_api(runtime_ids, codes, "Run all cells")

    async def run_stale_cells(self) -> None:
        await self.run_all_cells()

    async def run_stale_cells_coalesced(self) -> None:
        """At most 2 runs (in-flight + 1 pending). Prevents rapid /sync
        POSTs from overwhelming the kernel.
        """
        if self._run_lock.locked():
            self._run_requested = True
            return

        async with self._run_lock:
            await self.run_all_cells()

        if self._run_requested:
            self._run_requested = False
            async with self._run_lock:
                await self.run_all_cells()

    async def initialize_seed_cell(self) -> bool:
        if not self._connected:
            raise RuntimeError("Not connected to Marimo")

        if self._seed_initialized:
            return False

        if not self._seed_guard:
            return False

        seed_name = self._seed_guard.seed_name
        if seed_name not in self._cells:
            logger.warning(f"Seed cell {seed_name} not found")
            return False

        logger.info(f"Initializing seed cell: {seed_name}")

        runtime_id = self._name_to_runtime_id.get(seed_name) or seed_name
        await self._run_cells_api([runtime_id], [self._cells[seed_name].code], "Initialize seed cell")

        self._seed_initialized = True
        return True

    async def add_cell(self, code: str, cell_id: str | None = None) -> str:
        """Includes parent cells in the run request so marimo recompiles
        them with updated used_refs, making their variables available.
        """
        if not self._connected:
            raise RuntimeError("Not connected to Marimo")

        if cell_id is None:
            cell_id = f"cell_{uuid.uuid4().hex[:8]}"

        stored_code, is_md = _store_code(code)
        new_defs, new_refs = parse_names(code)
        self._cells[cell_id] = CellInfo(
            id=cell_id, code=stored_code, name=cell_id, is_markdown=is_md, defs=new_defs,
        )
        self._register_cell_id(cell_id, cell_id)

        exec_code = self._exec_code(cell_id)
        cell_ids_to_run = [cell_id]
        codes_to_run = [exec_code]

        # Each ref has exactly one defining cell in marimo
        for ref in new_refs - new_defs:
            for name, cell in self._cells.items():
                if name == cell_id:
                    continue
                if self._seed_guard and self._seed_guard.is_seed_cell(name):
                    continue
                if ref in cell.defs:
                    runtime_id = self._name_to_runtime_id.get(name, name)
                    if runtime_id not in cell_ids_to_run:
                        cell_ids_to_run.insert(0, runtime_id)
                        codes_to_run.insert(0, cell.code)
                    break

        await self._sync_signals_to_marimo(force=True)
        await self._run_cells_api(cell_ids_to_run, codes_to_run, "Add cell")
        return cell_id

    async def add_ui_cell(self, code: str, cell_id: str | None = None) -> str:
        await self._ensure_ui_preamble()
        return await self.add_cell(code, cell_id=cell_id)

    async def delete_cell(self, name: str) -> None:
        if not self._connected:
            raise RuntimeError("Not connected to Marimo")

        runtime_id = self._name_to_runtime_id.get(name, name)
        try:
            await self._run_cells_api([runtime_id], ["pass"], "Delete cell")
        except Exception as e:
            logger.warning(f"Failed to clear cell {name} in kernel: {e}")

        self._unregister_cell_id(name)
        self._cells.pop(name, None)

    async def set_cell_config(self, name: str, *, hide_code: bool | None = None) -> None:
        if name not in self._cells:
            raise ValueError(f"Unknown cell: {name}")
        if hide_code is not None:
            self._cells[name].hide_code = hide_code

    async def _ensure_ui_preamble(self) -> str:
        if STARIMO_PREAMBLE_NAME not in self._cells:
            logger.info("Creating UI preamble cell")
            await self.add_cell(STARIMO_UI_PREAMBLE_CODE, cell_id=STARIMO_PREAMBLE_NAME)
        return STARIMO_PREAMBLE_NAME

    async def _ensure_seed_cell(self) -> str | None:
        if self._seed_guard is not None:
            return self._seed_guard.seed_name
        if STARIMO_SEED_NAME in self._cells:
            self._seed_guard = SeedCellGuard(STARIMO_SEED_NAME)
            return STARIMO_SEED_NAME
        logger.info("Creating bootstrap seed cell")
        await self.add_cell(STARIMO_SEED_BOOTSTRAP_CODE, cell_id=STARIMO_SEED_NAME)
        self._seed_guard = SeedCellGuard(STARIMO_SEED_NAME)
        self._seed_initialized = True
        return STARIMO_SEED_NAME

    # ── Save ──────────────────────────────────────────────────────────

    async def save(self) -> str:
        if not self._connected:
            raise RuntimeError("Not connected to Marimo")
        if not self.notebook_path:
            raise ValueError("No notebook path configured")

        token = await self._ensure_server_token()
        headers = self._get_api_headers(token)

        if STARIMO_SEED_NAME in self._cells:
            metadata = {}
            for key in ("notebook_title", "notebook_description"):
                val = self._signal_registry.get(key)
                if val is not None:
                    metadata[key] = val
            cell_notes = {name: cell.note for name, cell in self._cells.items()
                          if cell.note and not name.startswith("_starimo_")}
            metadata['cell_notes'] = cell_notes
            self._cells[STARIMO_SEED_NAME].code = update_starimo_values_code(
                self._cells[STARIMO_SEED_NAME].code, metadata
            )

        # Exclude signal sync cell — runtime-only, not persisted
        # Seed cell first so marimo sees `mo` definition before dependent cells
        names = [n for n in self._cells if n != STARIMO_SIGNAL_SYNC_NAME]
        if STARIMO_SEED_NAME in names:
            names.remove(STARIMO_SEED_NAME)
            names.insert(0, STARIMO_SEED_NAME)
        runtime_ids = [self._name_to_runtime_id.get(n, n) for n in names]

        codes = [self._exec_code(n) for n in names]

        configs = [
            {"column": None, "disabled": False, "hide_code": self._cells[n].hide_code}
            for n in names
        ]

        logger.debug(f"Saving {len(names)} cells to {self.notebook_path}")

        assert self._http, "connect() must be called before HTTP operations"
        response = await self._http.post(
            "/api/kernel/save",
            json={
                "cellIds": runtime_ids, "codes": codes, "names": names,
                "configs": configs, "filename": str(self.notebook_path), "persist": True,
            },
            headers=headers,
            timeout=30.0,
        )

        if response.status_code != 200:
            logger.error(f"Save failed: {response.status_code} - {response.text}")
            raise RuntimeError(f"Save failed ({response.status_code}): {response.text}")

        logger.info("Notebook saved successfully")
        return response.text

    # ── Properties ────────────────────────────────────────────────────

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def ready(self) -> bool:
        return self._ready

    @property
    def resumed(self) -> bool:
        return self._resumed

    @property
    def variables(self) -> dict[str, Any]:
        return self._signal_registry.get_all()

    def get_cell(self, cell_id: str) -> CellInfo | None:
        return self._cells.get(cell_id)

    def clear_cell_output(self, cell_id: str) -> None:
        cell = self._cells.get(cell_id)
        if cell:
            cell.output = None

    @property
    def cells(self) -> dict[str, CellInfo]:
        return self._cells.copy()


__all__ = ["MarimoBridge"]
